/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Configuration.MyConnexion;
import IService.*;
import Entite.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author eloss
 */
public class ServiceJoueur implements IServiceJoueur {

    Connection cnx;
    PreparedStatement pst;

    public ServiceJoueur() {
        cnx = MyConnexion.getInstance();
    }

    @Override
    public boolean ajouter(Joueur j) {
        if (j == null) {
            return false;
        }
        try {
            String req = "INSERT INTO joueur (id_equipe,nom,prenom,age,poste,numero,club,image,posteF,prix) values(?,?,?,?,?,?,?,?,?,?)";
            pst = cnx.prepareStatement(req ,PreparedStatement.RETURN_GENERATED_KEYS);
            pst.setInt(1, j.getEquipe().getId());
            pst.setString(2, j.getNom());
            pst.setString(3, j.getPrenom());
            pst.setInt(4, j.getAge());
            pst.setString(5, j.getPoste());
            pst.setInt(6, j.getNumero());
            pst.setString(7, j.getClub());
            pst.setString(8,j.getImage());
            if(j.getPoste().equals("G")){
                j.setPosteF(Joueur.posteF.Gardien);
            }
            else if(j.getPoste().equals("AD") || j.getPoste().equals("AC") || j.getPoste().equals("AG") || j.getPoste().equals("A")){
                j.setPosteF(Joueur.posteF.Attaquant);
            }
            else if(j.getPoste().equals("P") || j.getPoste().equals("R10")){
                j.setPosteF(Joueur.posteF.Milieu);
            }
            else if(j.getPoste().equals("Dg") || j.getPoste().equals("Dd")){
                j.setPosteF(Joueur.posteF.Defenseur);
            }
            Random R = new Random();
            float a =(float) R.nextInt(9) + 4;
            j.setPrix(a);
            pst.setObject(9, j.getPosteF().toString());
            pst.setObject(10, j.getPrix());
            pst.executeUpdate();
            ResultSet rs = pst.getGeneratedKeys();
            rs.first();
            j.setId(rs.getInt(1));
        } catch (SQLException s) {
            System.out.println(s);
        }
        return true;
    }

    @Override
    public void modifier(int id, Equipe Equipe, String nom, String prenom, int age, String poste, int numero, String club,String image) {
        try {
            String req = "UPDATE joueur SET id_equipe=?,nom=?,prenom=?,age=?,poste=?,numero=?,club=?,image=? WHERE id=?";
            pst = cnx.prepareStatement(req);
            pst.setInt(1, Equipe.getId());
            pst.setString(2, nom);
            pst.setString(3, prenom);
            pst.setInt(4, age);
            pst.setString(5, poste);
            pst.setInt(6, numero);
            pst.setString(7, club);
            pst.setString(8,image);
            pst.setInt(9, id);
            pst.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    @Override
    public boolean supprimer(Joueur j) {
        if (j == null) {
            return false;
        }
        try {
            String req = "DELETE FROM joueur WHERE id=?";
            pst = cnx.prepareStatement(req);
            pst.setInt(1, j.getId());
            pst.executeUpdate();
        } catch (SQLException s) {
            System.out.println(s);
        }
        return true;
    }

    @Override
    public Joueur get(int id) {
        Joueur E = new Joueur();
        try {
            String req = "SELECT * FROM joueur WHERE id=?";
            pst = cnx.prepareStatement(req);
            pst.setInt(1, id);
            ResultSet res = pst.executeQuery();
            while (res.next()) {
                E.setId(id);
                E.setEquipe(new ServiceEquipe().get(res.getInt(2)));
                E.setNom(res.getString("nom"));
                E.setPrenom(res.getString("prenom"));
                E.setAge(res.getInt(5));
                E.setPoste(res.getString("poste"));
                E.setNumero(res.getInt(7));
                E.setClub(res.getString("club"));
                E.setImage(res.getString("image"));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return E;
    }
    public Joueur get(String nom) {
        Joueur E = new Joueur();
        try {
            String req = "SELECT * FROM joueur WHERE nom=?";
            pst = cnx.prepareStatement(req);
            pst.setString(1, nom);
            ResultSet res = pst.executeQuery();
            while (res.next()) {
                E.setId(res.getInt(1));
                E.setEquipe(new ServiceEquipe().get(res.getInt(2)));
                E.setNom(res.getString("nom"));
                E.setPrenom(res.getString("prenom"));
                E.setAge(res.getInt(5));
                E.setPoste(res.getString("poste"));
                E.setNumero(res.getInt(7));
                E.setClub(res.getString("club"));
                E.setImage(res.getString("image"));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return E;
    }

    @Override
    public List<Joueur> getALL() {
        List<Joueur> liste = new ArrayList<>();
        try {
            String req = "SELECT * FROM joueur";
            pst = cnx.prepareStatement(req);
            ResultSet res = pst.executeQuery();
            while (res.next()) {
                Joueur j = new Joueur(res.getInt(1), new ServiceEquipe().get(res.getInt(2)), res.getString("nom"), res.getString("prenom"), res.getInt(5), res.getString("poste"), res.getInt(7), res.getString("club"),res.getString("image"),Joueur.posteF.valueOf(res.getString("posteF")),res.getFloat("prix"));
                liste.add(j);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return liste;
    }

    @Override
    public List<Joueur> D_chercher(String nom) {
        List<Joueur> liste = new ArrayList<>();
        try {
            String req = "SELECT * FROM joueur WHERE nom LIKE '" + nom + "%'";
            pst = cnx.prepareStatement(req);
            ResultSet res = pst.executeQuery();
            while (res.next()) {
                Joueur j = new Joueur(res.getInt(1), new ServiceEquipe().get(res.getInt(2)), res.getString("nom"), res.getString("prenom"), res.getInt(5), res.getString("poste"), res.getInt(7), res.getString("club"),res.getString("image"),Joueur.posteF.valueOf(res.getString("posteF")),res.getFloat("prix"));
                liste.add(j);
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return liste;
    }

    @Override
    public Equipe get_Equipe(Joueur j) {
        Equipe eq = new Equipe();
        try {
            String req = "SELECT * FROM equipe WHERE id=(SELECT id_equipe FROM joueur WHERE id=?)";
            pst = cnx.prepareStatement(req);
            pst.setInt(1, j.getId());
            ResultSet res = pst.executeQuery();
            while (res.next()) {
                eq.setId(res.getInt(1));
                eq.setEntraineur(new ServiceEntraineur().get(res.getInt(2)));
                eq.setNom(res.getString("nom"));
                eq.setDrapeau(res.getString("drapeau"));
                eq.setMaillot(res.getString("maillot"));
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return eq;
    }

    @Override
    public Entraineur get_Entraineur(Joueur j) {
        ServiceEquipe D = new ServiceEquipe();
        return D.get_Entraineur(this.get_Equipe(j));
    }

    @Override
    public List<Joueur> get_tri_selon(String champs) {
        List<Joueur> liste = new ArrayList<>();
        if (champs.equals("id") || champs.equals("id_equipe") || champs.equals("nom") || champs.equals("prenom") || champs.equals("age") || champs.equals("poste") || champs.equals("numero") || champs.equals("club")) {
            try {
                String req = "SELECT * FROM joueur ORDER BY ?";
                pst = cnx.prepareStatement(req);
                pst.setString(1, champs);
                ResultSet res = pst.executeQuery();
                while (res.next()) {
                    Joueur j = new Joueur(res.getInt(1), new ServiceEquipe().get(res.getInt(2)), res.getString("nom"), res.getString("prenom"), res.getInt(5), res.getString("poste"), res.getInt(7), res.getString("club"),res.getString("image"),Joueur.posteF.valueOf(res.getString("posteF")),res.getFloat("prix"));
                    liste.add(j);
                }
            } catch (SQLException e) {
                System.out.println(e);
            }
        }
        return liste;
    }
    public List<Joueur> recuperer_Par_Nom_Eq(String n){
         List<Joueur> l=new ArrayList<>();
       String req="SELECT * FROM joueur,equipe  WHERE equipe.nom='"+n+"'AND joueur.id_equipe=equipe.id ";
        try {
            Statement s=MyConnexion.getInstance().createStatement();
           // PreparedStatement pst= MyConnexion.getInstance().prepareStatement(req);
            //pst.setString(1, n);
            ResultSet r=s.executeQuery(req);
            while(r.next()){
               Joueur j = new Joueur();
               j.setId(r.getInt("id"));
               j.setNom(r.getString("nom"));
               j.setPrenom(r.getString("prenom"));
               l.add(j);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceMatch.class.getName()).log(Level.SEVERE, null, ex);
        }
       return l;
    }
    public int recuperer_Id_par_nom(String n){
        int i=0;
        try{
            String req ="SELECT id FROM joueur WHERE nom=?";
            PreparedStatement pst= MyConnexion.getInstance().prepareStatement(req);
            pst.setString(1, n);
           // pst.setString(2, p);
            ResultSet res = pst.executeQuery();
            while(res.next()){
                i=res.getInt(1);      
            }
        }catch(SQLException e){
            System.out.println(e);
        }
        return i;
    }
    public int nb_but_marque(Joueur joueur){
        int somme=0 ;
        ServiceEvenement SE = new ServiceEvenement();
        for(Evenement E : SE.get_evenement_by_joueur(joueur)){
            if(E.getBut() == 1){
                somme++ ;
            }
        }
        return somme ;
    }
}
