/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Configuration.MyConnexion;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import Entite.*;
import IService.IServiceGroupe;

/**
 *
 * @author hseli
 */
public class ServiceGroupe implements IServiceGroupe {

    @Override
    public void ajouter_Groupe(Groupe G) {
        String req="INSERT INTO groupe(nom) VALUES (?)";
           try {
               PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req,PreparedStatement.RETURN_GENERATED_KEYS);
               ps.setString(1,G.getNom());              
               int i=G.getId();
               ps.executeUpdate();
               ResultSet r=ps.getGeneratedKeys();
               if(r.next()){
                   G.setId(r.getInt(1));
               }
           } catch (SQLException ex) {
               Logger.getLogger(ServiceGroupe.class.getName()).log(Level.SEVERE, null, ex);
           }
    }

    @Override
    public List<Groupe> get_Groupe() {
        List<Groupe> l=new ArrayList<>();
       String req="SELECT * FROM groupe";
        try {
            Statement s=MyConnexion.getInstance().createStatement();
            ResultSet r=s.executeQuery(req);
            while(r.next()){
                Groupe m=new Groupe();
                m.setId(r.getInt(1));
                //m.setGM(new ServiceMatch().get_Match_Par_ID(r.getInt(1)));
                m.setGM(new ServiceMatch().get_Match_by_group(r.getInt(1)));
                m.setNom(r.getString(2));
                m.setEtat(Groupe.Etat.valueOf(r.getString(3)));
                l.add(m);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceGroupe.class.getName()).log(Level.SEVERE, null, ex);
        }
       return l;
    }

    @Override
    public int count_Groupe() {
         String req="SELECT COUNT(*) FROM groupe";
        try {
            Statement s=MyConnexion.getInstance().createStatement();
            ResultSet r=s.executeQuery(req);
            r.first();
            return r.getInt(1);
        } catch (SQLException ex) {
            Logger.getLogger(ServiceGroupe.class.getName()).log(Level.SEVERE, null, ex);
        }
        return -1;
    }

    @Override
    public Groupe get(int id) {
         Groupe E = new Groupe() ;
        try{
            String req ="SELECT * FROM groupe WHERE id=?";
           PreparedStatement pst= MyConnexion.getInstance().prepareStatement(req);
            pst.setInt(1, id);
            ResultSet res = pst.executeQuery();
            while(res.next()){
                E.setId(id);
                //E.setGM(new ServiceMatch().get_Match_by_group(res.getInt(1)));
                E.setNom(res.getString(2));         
                E.setEtat(Groupe.Etat.valueOf(res.getString(3)));
            }
        }catch(SQLException e){
            System.out.println(e);
        }
        return E;
    }
    
    public Groupe get(String nom) {
         Groupe E = new Groupe() ;
        try{
            String req ="SELECT * FROM groupe WHERE nom=?";
           PreparedStatement pst= MyConnexion.getInstance().prepareStatement(req);
            pst.setString(1, nom);
            ResultSet res = pst.executeQuery();
            while(res.next()){
                E.setId(res.getInt(1));
                //E.setGM(new ServiceMatch().get_Match_by_group(res.getInt(1)));
                E.setNom(res.getString(2));          
                E.setEtat(Groupe.Etat.valueOf(res.getString(3)));
            }
        }catch(SQLException e){
            System.out.println(e);
        }
        return E;
    }
    public int recuperer_Id_par_nom(String n){
        int i=0;
        try{
            String req ="SELECT id FROM groupe WHERE nom=?";
            PreparedStatement pst= MyConnexion.getInstance().prepareStatement(req);
            pst.setString(1, n);
            ResultSet res = pst.executeQuery();
            while(res.next()){
                i=res.getInt(1);      
            }
        }catch(SQLException e){
            System.out.println(e);
        }
        return i;
    }
    public void update_etat(){
        List<String> liste_nom = new ArrayList<>();
        ServiceEquipe SE = new ServiceEquipe() ;
        liste_nom.add("A") ;
        liste_nom.add("B") ;
        liste_nom.add("C") ;
        liste_nom.add("D") ;
        liste_nom.add("E") ;
        liste_nom.add("F") ;
        liste_nom.add("G") ;
        liste_nom.add("H") ;
        for(String nom : liste_nom){
            int aux =0;
            for(Equipe E : SE.get_by_group(nom)){
                if(E.getNb_match_joue() == 3)
                    aux++;
            }
            if(aux == 4){
                modifier_etat(nom);
            }
        }
    }
    public void modifier_etat(String nom){
        try{
            String req = "UPDATE groupe SET Etat=? WHERE nom=?";
            PreparedStatement pst = MyConnexion.getInstance().prepareStatement(req);
            pst.setObject(1, Groupe.Etat.Finis.toString());
            pst.setString(2, nom);
            pst.executeUpdate();
        }catch(SQLException e){
            System.out.println(e + " L'erreur provient de modifier_etat -> ServiceGroupe");
        }
    }
}
