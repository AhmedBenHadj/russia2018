/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Configuration.MyConnexion;
import Entite.*;
import IService.IServiceEquipeFantasy;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author quickstrikes96
 */
public class ServiceEquipeFantasy implements IServiceEquipeFantasy {

    @Override
    public void creer_equipefantasy(EquipeFantasy E) {

        try {
            String query = "insert into equipe_fantasy (id_user , nom , totalpoints , classement , transfers , valeur , banque) values(?,?,0,0,0,0,100)";
            PreparedStatement stm = MyConnexion.getInstance().prepareStatement(query,PreparedStatement.RETURN_GENERATED_KEYS);
            stm.setInt(1, E.getUser().getId());
            stm.setString(2, E.getNom());
            stm.executeUpdate();
            ResultSet r = stm.getGeneratedKeys();
            r.first();
            E.setId(r.getInt(1));

            System.out.println("Equipe Fantasy ajoutée correctement");
        } catch (SQLException ex) {
            Logger.getLogger(ServiceJoueurFantasy.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    @Override
    public List<EquipeFantasy> afficher_equipefantasy() {
        
                List<EquipeFantasy> liste = new ArrayList<>();
        {
            try {
                String req = "SELECT * FROM equipe_fantasy";
                PreparedStatement pst = MyConnexion.getInstance().prepareStatement(req);
                ResultSet res = pst.executeQuery();
                while (res.next()) {
                    EquipeFantasy E = new EquipeFantasy(res.getString(3));
                    liste.add(E);
                }
            } catch (SQLException ex) {
                Logger.getLogger(ServiceJoueurFantasy.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return liste;
    }
    
    @Override
    public EquipeFantasy get(int id) {
        EquipeFantasy E = new EquipeFantasy();
        {
            try {
                String req = "SELECT * FROM equipe_fantasy WHERE id=?";
                PreparedStatement pst = MyConnexion.getInstance().prepareStatement(req);
                pst.setInt(1, id);
                ResultSet res = pst.executeQuery();
                while (res.next()) {
                    E.setId(id);
                    E.setUser(new ServiceUser().retrieveId(res.getInt(2)));
                    E.setNom(res.getString("nom"));
                    E.setTotalpoints(res.getInt(4));
                    E.setClassement(res.getInt(5));
                    E.setTransfers(res.getInt(6));
                    E.setValeur(res.getInt(7));
                    E.setBanque(res.getInt(8));
                }
            } catch (SQLException ex) {
                Logger.getLogger(ServiceEquipeFantasy.class.getName()).log(Level.SEVERE, null, ex);
            }
        } 
        return E;
    }

}
