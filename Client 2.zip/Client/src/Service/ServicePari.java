/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Configuration.MyConnexion;
import Entite.*;
import Entite.Pari.EtatPari;
import Utilitaire.SMS;
import com.nexmo.client.NexmoClientException;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author skanderbejaoui
 */
public class ServicePari implements IService.IServicePari {

    String reqe = "Select * from "
            + "(SELECT equipe.nom from equipe,match_2018,pari where equipe.id=match_2018.id_equipe_1 and match_2018.id=pari.id_match and pari.id =?) t1"
            + "INNER JOIN "
            + "(SELECT equipe.nom,pari.cote,pari.mise from equipe,match_2018,pari where equipe.id=match_2018.id_equipe_2 and match_2018.id=pari.id_match and pari.id =?) t2";

    @Override
    public void ajouterPari(Pari p) {
        String req = "insert into pari(id_match,cote,id_fiche_pari,mise,gain,type,etat,resultat)Values(?,?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req, PreparedStatement.RETURN_GENERATED_KEYS);

            ps.setInt(1, p.getM().getId());
            ps.setFloat(2, p.getCote());
            ps.setInt(3, p.getFp().getId());
            ps.setFloat(4, p.getMise());
            ps.setFloat(5, Float.parseFloat(p.getGain().getText()));
            ps.setInt(6, 0);
            ps.setString(7, p.getEtat().Encours.toString());
            ps.setString(8, String.valueOf(p.getResultat()));
            ps.executeUpdate();
            ResultSet res = ps.getGeneratedKeys();
            res.first();
            p.setId(res.getInt(1));
            p.setType(0);

        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void annulerPari(Pari p) {
        String req = "delete from pari where id = ?";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1, p.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void modifierPari(Pari p) {
        String req = "update pari set etat =? where id= ?";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setString(1, String.valueOf(p.getEtat()));
            ps.setInt(2, p.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public Pari afficherPari(int id) {
        Pari p = new Pari();

        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(reqe);
            ps.setInt(1, id);
            ps.setInt(2, id);
            ResultSet res = ps.executeQuery();
            if (res.first()) {
                p.getM().getE1().setNom(res.getString(1));

                p.getM().getE2().setNom(res.getString(2));
                p.setCote(res.getFloat(3));

                p.setMise(res.getFloat(4));

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;

    }

    @Override
    public Pari rechercherPari(int id) {
        String req = "SELECT * FROM pari WHERE id=?";
        Pari p = new Pari();
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1, id);
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                p.setId(res.getInt(1));
                p.getM().setId(2);

                p.setCote(res.getFloat(3));

                p.getFp().setId(res.getInt(4));
                p.setMise(res.getFloat(5));

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return p;
    }

    public List<Integer> get_idMatch() {
        List<Integer> liste = new ArrayList<>();
        String req = "Select id from match_2018";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                liste.add(res.getInt(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return liste;
    }

    public Match get_Match_Pari(int id) {

        Match m = null;
        String req = "SELECT * FROM (SELECT equipe.nom,match_2018.cote_eq1,match_2018.cote_nul from match_2018,equipe WHERE equipe.id=match_2018.id_equipe_1 and match_2018.id=?)t1 INNER JOIN (SELECT match_2018.cote_eq2,equipe.nom from match_2018,equipe WHERE equipe.id=match_2018.id_equipe_2 and match_2018.id=?)t2";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1, id);
            ps.setInt(2, id);
            ResultSet res = ps.executeQuery();
            if (res.first()) {

                m = new Match();
                m.getE1().setNom(res.getString(1));
                m.setCote_eq1(res.getFloat(2));
                m.setCote_nul(res.getFloat(3));
                m.setCote_eq2(res.getFloat(4));
                m.getE2().setNom(res.getString(5));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return m;

    }

    @Override
    public void ajouterPariJ(Pari p) {
        String req = "insert into pari(id_match,cote,id_fiche_pari,mise,gain,type)Values(?,?,?,?,?,?)";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req, PreparedStatement.RETURN_GENERATED_KEYS);

            ps.setInt(1, p.getM().getId());
            ps.setFloat(2, p.getCote());
            ps.setInt(3, p.getFp().getId());
            ps.setFloat(4, p.getMise());
            ps.setFloat(5, Float.parseFloat(p.getGain().getText()));
            ps.setInt(6, 0);
            ps.executeUpdate();
            ResultSet res = ps.getGeneratedKeys();
            res.first();
            p.setId(res.getInt(1));
            p.setType(0);

        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public Match get_Match_PariJ(int id) {
        Match m = null;
        String req = "SELECT * FROM (SELECT equipe.nom,match_2018.cote_eq1,match_2018.cote_nul from match_2018,equipe,fiche_pari,pari WHERE equipe.id=match_2018.id_equipe_1 and match_2018.id=? and fiche_pari.id=pari.id_fiche_pari and pari.id_match=match_2018.id and fiche_pari.type=1)t1"
                + "INNER JOIN"
                + "(SELECT match_2018.cote_eq2,equipe.nom from match_2018,equipe,fiche_pari,pari WHERE equipe.id=match_2018.id_equipe_2 and match_2018.id=? and fiche_pari.id=pari.id_fiche_pari and pari.id_match=match_2018.id and fiche_pari.type=1)t2";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1, id);
            ps.setInt(2, id);
            ResultSet res = ps.executeQuery();
            if (res.first()) {

                m = new Match();
                m.getE1().setNom(res.getString(1));
                m.setCote_eq1(res.getFloat(2));
                m.setCote_nul(res.getFloat(3));
                m.setCote_eq2(res.getFloat(4));
                m.getE2().setNom(res.getString(5));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return m;
    }

    public Map<User, List<FichePari>> get_user_et_leur_fiche() {
        Map<User, List<FichePari>> mymap = new HashMap<>();
        PreparedStatement pst;
        for (User u : new ServiceFichePari().getAllUsers()) {
            List<FichePari> liste = new ArrayList<>();
            try {
                String req = "SELECT id FROM fiche_pari WHERE id_user=?";
                pst = MyConnexion.getInstance().prepareStatement(req);
                pst.setInt(1, u.getId());
                ResultSet res_1 = pst.executeQuery();
                while (res_1.next()) {
                    FichePari fp = new ServiceFichePari().rechercherfichepari(res_1.getInt(1));
                    if (mymap.containsKey(u)) {
                        if (!mymap.get(u).contains(fp)) {
                            mymap.get(u).add(fp);
                        }
                    } else {
                        mymap.put(u, liste);
                        if (!mymap.get(u).contains(fp)) {
                            liste.add(fp);
                            mymap.put(u, liste);
                        }
                    }

                }
            } catch (SQLException e) {
                System.out.println(e + " l'erreur provient de get_user par leur id");
            }
        }
        return mymap;
    }

    public List<Pari> afficher_etat_pari(EtatPari etat) {
        String req = "Select * from pari where etat =?";
        List<Pari> lp = new ArrayList<>();
        try {

            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setString(1, String.valueOf(EtatPari.Encours));
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                Pari p = new Pari();
                p.setId(res.getInt(1));
                p.getM().setId(res.getInt(2));
                p.getFp().setId(res.getInt(3));
                p.setMise(res.getFloat(4));
                p.getGain().setText(String.valueOf(res.getFloat(5)));
                p.setCote(res.getFloat(6));
                p.setType(res.getInt(7));
                p.setEtat(Pari.EtatPari.valueOf(res.getString(8)));
                p.setResultat(Pari.ResultatPari.valueOf(res.getString(9)));
                lp.add(p);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lp;
    }

    public Match getmatch(Pari P) {
        String req = "SELECT id_match FROM pari WHERE id=?";
        Match M = new Match();
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1, P.getId());
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                M = new ServiceMatch().get(res.getInt(1));
            }
        } catch (SQLException e) {
            System.out.println(e + " L'erreur vient de getmatch ,servicepari");
        }
        return M;
    }

    public void updatepari() {
        ServiceMatch SM = new ServiceMatch();
        ServiceEquipe SE = new ServiceEquipe();
        ServiceUser SU = new ServiceUser();
        ServiceFichePari SFP = new ServiceFichePari();
        for (User U : SU.retrieve()) {
            if (this.get_user_et_leur_fiche().get(U) != null) {
                for (FichePari FP : this.get_user_et_leur_fiche().get(U)) {
                    for (Pari P : FP.getParis()) {
                        if(this.getmatch(P).getEtat().equals(Match.EtatMatch.Termine)){
                            if (P.getEtat().equals(Pari.EtatPari.Encours)) {
                                if (SE.gagnant(this.getmatch(P)) == null) {
                                    if (P.getResultat().equals(Pari.ResultatPari.x)) {
                                        P.setEtat(EtatPari.Gagne);
                                        this.modifierPari(P);
                                    } else {
                                        P.setEtat(EtatPari.Perdu);
                                        this.modifierPari(P);
                                    }

                                } else {
                                    if (this.getmatch(P).getE1().equals(SE.gagnant(this.getmatch(P)))) {
                                        if (P.getResultat().equals(Pari.ResultatPari.un)) {
                                            P.setEtat(EtatPari.Gagne);
                                            this.modifierPari(P);
                                        } else {
                                            P.setEtat(EtatPari.Perdu);
                                            this.modifierPari(P);
                                        }
                                    } else if (this.getmatch(P).getE2().equals(SE.gagnant(this.getmatch(P)))) {
                                        if (P.getResultat().equals(Pari.ResultatPari.deux)) {
                                            P.setEtat(EtatPari.Gagne);
                                            this.modifierPari(P);
                                        } else {
                                            P.setEtat(EtatPari.Perdu);
                                            this.modifierPari(P);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public void updateFichePariandUser() {
        ServiceFichePari SFP = new ServiceFichePari();
        ServiceUser SU = new ServiceUser();
        boolean aux = false;
        int i = 0;
        for (User U : new ServiceUser().retrieve()) {
            if (this.get_user_et_leur_fiche().get(U) != null) {
                for (FichePari FP : this.get_user_et_leur_fiche().get(U)) {
                    if (FP.getEtat().equals(FichePari.EtatFiche.Encours)) {
                        i = 0;
                        for (Pari P : SFP.getallPari(FP)) {
                            if (this.getmatch(P).getEtat().equals(Match.EtatMatch.Termine)) {
                                if (P.getEtat().equals(Pari.EtatPari.Perdu)) {
                                    FP.setEtat(FichePari.EtatFiche.Perdu);
                                    SFP.modifierPari(FP);
                                    i++;
                                    break;
                                }
                            }
                        }
                        if (i == 0 && this.ifallmatchplayed(FP)) {
                            FP.setEtat(FichePari.EtatFiche.Gagne);
                            SFP.modifierPari(FP);
                            System.out.println(FP.getGain());
                            U.setJeton(U.getJeton() + FP.getGain());
                            SU.update(U);
                            try {
                                SMS.creer();
                            } catch (IOException ex) {
                                Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
                            } catch (NexmoClientException ex) {
                                Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                }
            }
        }
    }

    public boolean ifallmatchplayed(FichePari FP) {
        for (Pari P : FP.getParis()) {
            if (!this.getmatch(P).getEtat().equals(Match.EtatMatch.Termine)) {
                return false;
            }
        }
        return true;
    }
}
