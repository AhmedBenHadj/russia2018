/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Configuration.MyConnexion;
import Entite.FichePari;
import Entite.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author skanderbejaoui
 */
public class ServiceFichePari implements IService.IServiceFichePari {

    @Override
    public void ajouterfichepari(FichePari fp) {
        String req = "insert into fiche_pari(cotetotal,etat,id_user,misetotal,date,gain,type)Values(?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req, PreparedStatement.RETURN_GENERATED_KEYS);

            ps.setFloat(1, fp.getCote_total());
            ps.setString(2, fp.getEtat().Encours.toString());
            ps.setInt(3, fp.getU().getId());
            ps.setFloat(4, fp.getMisetotal());
            ps.setDate(5, fp.getDate());
            ps.setFloat(6, fp.getGain());
            ps.setInt(7, 0);
            ps.executeUpdate();
            ResultSet res = ps.getGeneratedKeys();
            res.first();
            fp.setId(res.getInt(1));
            fp.setType(0);
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

     public void modifierPari(FichePari fp) {
        String req = "update fiche_pari set etat =? where id= ?";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setString(1, String.valueOf(fp.getEtat()));
            ps.setInt(2, fp.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
     
    @Override
    public List<Pari> afficherfichepari(FichePari fp) {
        List<Pari> fp1 = new ArrayList<>();
        ServicePari sp = new ServicePari();
        for (Pari p : fp.getParis()) {
            fp1.add(sp.afficherPari(p.getId()));
        }
        return fp1;
    }

    @Override
    public FichePari rechercherfichepari(int id) {
        String req = "SELECT * FROM fiche_pari WHERE id=?";
        FichePari fp = new FichePari();
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1, id);
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                fp.setId(res.getInt(1));
                fp.setCote_total(res.getFloat(2));
                fp.setEtat(FichePari.EtatFiche.valueOf(res.getString(3)));
                fp.setParis(this.getallPari(fp));
                fp.getU().setId(res.getInt(4));
                fp.setMisetotal(res.getFloat(5));
                fp.setDate(res.getDate(6));
                fp.setGain(res.getFloat(7));
                fp.setType(res.getInt(8));

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return fp;
    }

    @Override
    public FichePari affichertousFP(int id, int idd) {
        String req = "SELECT * FROM"
                + "(SELECT equipe.nom FROM equipe,match_2018,pari,fiche_pari,user WHERE equipe.id=match_2018.id_equipe_1 and match_2018.id=pari.id_match and pari.id_fiche_pari = fiche_pari.id AND user.id=? and fiche_pari.id_user = user.id AND pari.id=?)t1"
                + "INNER JOIN"
                + "(SELECT equipe.nom,fiche_pari.cotetotal,fiche_pari.misetotal,fiche_pari.gain,fiche_pari.date FROM equipe,match_2018,pari,fiche_pari,user WHERE equipe.id=match_2018.id_equipe_2 and match_2018.id=pari.id_match and pari.id_fiche_pari = fiche_pari.id AND user.id=? and fiche_pari.id_user = user.id AND pari.id=?)t2";
        FichePari fp = new FichePari();
        fp.setId(idd);
        List<Pari> list = new ArrayList<>();
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1, idd);

            ps.setInt(2, id);
            ps.setInt(3, idd);
            ps.setInt(4, id);
            ResultSet res = ps.executeQuery();
            if (res.first()) {
                Pari p = new Pari();
                p.getM().getE1().setNom(res.getString(1));
                p.getM().getE2().setNom(res.getString(2));
                fp.getParis().add(p);

                fp.setCote_total(res.getFloat(3));
                fp.setMisetotal(res.getFloat(4));
                fp.setGain(res.getFloat(5));
                fp.setDate(res.getDate(6));
            }

        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return fp;
    }

    public List<Integer> get_idPari() {
        List<Integer> liste = new ArrayList<>();
        String req = "Select id from pari";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                liste.add(res.getInt(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return liste;
    }

    public FichePari afficherModerateur(int id) {
        String req = "SELECT * FROM (SELECT equipe.nom FROM equipe,match_2018,pari,fiche_pari,user WHERE equipe.id=match_2018.id_equipe_1 and match_2018.id=pari.id_match and pari.id_fiche_pari = fiche_pari.id AND fiche_pari.id_user = user.id and pari.id=?)t1 INNER JOIN (SELECT equipe.nom,fiche_pari.cotetotal,fiche_pari.misetotal,fiche_pari.gain,fiche_pari.date,user.username FROM equipe,match_2018,pari,fiche_pari,user WHERE equipe.id=match_2018.id_equipe_2 and match_2018.id=pari.id_match and pari.id_fiche_pari = fiche_pari.id AND fiche_pari.id_user = user.id and pari.id=?)t2";
        FichePari fp = new FichePari();
        fp.setId(id);
        List<Pari> list = new ArrayList<>();
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1, id);

            ps.setInt(2, id);
            ResultSet res = ps.executeQuery();
            if (res.first()) {
                Pari p = new Pari();
                p.getM().getE1().setNom(res.getString(1));
                p.getM().getE2().setNom(res.getString(2));
                fp.getParis().add(p);

                fp.setCote_total(res.getFloat(3));
                fp.setMisetotal(res.getFloat(4));
                fp.setGain(res.getFloat(5));
                fp.setDate(res.getDate(6));
                fp.getU().setUsername(res.getString(7));
            }

        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return fp;
    }

    public void ajouterfichepariJ(FichePari fp) {
        String req = "insert into fiche_pari(cotetotal,etat,id_user,misetotal,date,gain,type)Values(?,?,?,?,?,?,?)";
        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req, PreparedStatement.RETURN_GENERATED_KEYS);

            ps.setFloat(1, fp.getCote_total());
            ps.setString(2, fp.getEtat().Encours.toString());
            ps.setInt(3, fp.getU().getId());
            ps.setFloat(4, fp.getMisetotal());
            ps.setDate(5, fp.getDate());
            ps.setFloat(6, fp.getGain());
            ps.setInt(7, 1);
            ps.executeUpdate();
            ResultSet res = ps.getGeneratedKeys();
            res.first();
            fp.setId(res.getInt(1));
            fp.setType(1);
        } catch (SQLException ex) {
            Logger.getLogger(ServicePari.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public List<User> getAllUsers() {
        List<User> lu = new ArrayList<>();
        try {
            String req = "Select * from user u join Fiche_Pari fp on u.id=fp.id_user";
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ResultSet res = ps.executeQuery();
            while (res.next()) {
                User u = null;
                u = new User();
                u.setId(res.getInt(1));
                u.setNom(res.getString(2));
                u.setPrenom(res.getString(3));
                u.setUsername(res.getString(4));
                u.setEmail(res.getString(5));
                u.setMdp(res.getString(6));
                u.setRole(User.Role.valueOf(res.getString(7)));
                u.setImage(res.getString(8));
                u.setType(res.getInt(9));
                u.setEtat(res.getInt(10));
                u.setDate_creation(res.getDate(11));
                u.setConnecte(User.Connecte.valueOf(res.getString(12)));
                lu.add(u);

            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceFichePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lu;
    }

    public List<Pari> getallPari(FichePari fp) {
        List<Pari> lp = new ArrayList<>();
        try {
            String req = "Select * from pari where id_fiche_pari=?";
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1,fp.getId());
            ResultSet res = ps.executeQuery();
            while(res.next()){
                Pari p = new Pari();
                p.setId(res.getInt(1));
                p.getM().setId(res.getInt(2));
                p.getFp().setId(res.getInt(3));
                p.setMise(res.getFloat(4));
                p.getGain().setText(String.valueOf(res.getFloat(5)));
                p.setCote(res.getFloat(6));
                p.setType(res.getInt(7));
                p.setEtat(Pari.EtatPari.valueOf(res.getString(8)));
                p.setResultat(Pari.ResultatPari.valueOf(res.getString(9)));
  
                lp.add(p);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceFichePari.class.getName()).log(Level.SEVERE, null, ex);
        }
        return lp;
        
    }

}
