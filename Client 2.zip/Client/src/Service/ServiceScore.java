/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Configuration.MyConnexion;
import Entite.Score;

import IService.IServiceScore;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hseli
 */
public class ServiceScore implements IServiceScore{

    public void ajouter_Score(Score S) {
        String req = "INSERT INTO score(id,A,B) VALUES (?,?,?)";

        try {
            PreparedStatement ps = MyConnexion.getInstance().prepareStatement(req, PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, S.getId());
            ps.setInt(2, S.getA());
            ps.setInt(3, S.getB());

            int i = S.getId();
            ps.executeUpdate();
            ResultSet r = ps.getGeneratedKeys();
            if (r.next()) {
                S.setId(r.getInt(1));
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceScore.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    @Override
    public Score get(int id) {
        Score S = new Score();
        try {
            String req = "SELECT * FROM score WHERE id=?";
            PreparedStatement pst = MyConnexion.getInstance().prepareStatement(req);
            pst.setInt(1, id);
            ResultSet res = pst.executeQuery();
            while (res.next()) {
                S.setId(id);
                S.setA(res.getInt(2));
                S.setB(res.getInt(3));
                

            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return S;
    }
    public void modifier_A(Score S) {
         String req="UPDATE score SET A=? WHERE id=? ";
        try {
            PreparedStatement ps=MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1,S.getA());
            //ps.setInt(2,S.getB());
            
            ps.setInt(2,S.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceScore.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    public void modifier_B(Score S) {
         String req="UPDATE score SET B=? WHERE id=? ";
        try {
            PreparedStatement ps=MyConnexion.getInstance().prepareStatement(req);
            ps.setInt(1,S.getB());
            //ps.setInt(2,S.getB());
            
            ps.setInt(2,S.getId());
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ServiceScore.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
      public List<Score> get_Score() {
        List<Score> l=new ArrayList<>();
       String req="SELECT * FROM score";
        try {
            Statement s=MyConnexion.getInstance().createStatement();
            ResultSet r=s.executeQuery(req);
            while(r.next()){
                Score m=new Score();
                m.setId(r.getInt(1));
                m.setA(r.getInt(2));
                m.setB(r.getInt(3));
                l.add(m);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceScore.class.getName()).log(Level.SEVERE, null, ex);
        }
       return l;
    }
      public List<Score> get_Score_par_id(int id) {
        List<Score> l=new ArrayList<>();
       String req="SELECT * FROM score WHERE id=?";
        try {
            PreparedStatement pst = MyConnexion.getInstance().prepareStatement(req);
            pst.setInt(1, id);
            ResultSet r=pst.executeQuery();
            while(r.next()){
               Score m=new Score();
                m.setId(id);
                m.setA(r.getInt(2));
                m.setB(r.getInt(3));
                l.add(m);
            }
        } catch (SQLException ex) {
            Logger.getLogger(ServiceScore.class.getName()).log(Level.SEVERE, null, ex);
        }
       return l;
    }
}
