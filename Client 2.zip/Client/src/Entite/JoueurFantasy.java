/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entite;

/**
 *
 * @author quickstrikes96
 */
public class JoueurFantasy {

    private int id;
    private Joueur Joueur;
    private int etat;
    private int points;
    private EquipeFantasy FEquipes;

    public JoueurFantasy() {
        

    }

    public JoueurFantasy(int id, Joueur Joueur, EquipeFantasy FEquipes, int posteF, int etat, int prix, int points) {
        this.id = id;
        this.Joueur = new Joueur();
        this.FEquipes = FEquipes;
        this.etat = etat;
        this.points = points;
    }

    public JoueurFantasy(Joueur Joueur, int etat, int points) {

        this.Joueur = Joueur;
        this.etat = etat;
        this.points = points;
    }

    public JoueurFantasy(int id, Joueur Joueur, int etat, int points) {
        this.id = id;
        this.Joueur = Joueur;
        this.etat = etat;
        this.points = points;
    }   

    public JoueurFantasy(Joueur Joueur) {
        this.Joueur = Joueur;
    }

    public JoueurFantasy(Joueur Joueur, int etat) {
        this.Joueur = Joueur;
        this.etat = etat;
    }

    public JoueurFantasy(int id, Joueur Joueur, EquipeFantasy Equi, int etat, int points) {
    }
    
    public Joueur getJoueur() {
        return Joueur;
    }

    public void setJoueur(Joueur Joueur) {
        this.Joueur = Joueur;
    }
    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }
    public int getPoints() {
        return points;
    }

    public void setPoints(int points) {
        this.points = points;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public EquipeFantasy getFEquipes() {
        return FEquipes;
    }

    public void setFEquipes(EquipeFantasy FEquipes) {
        this.FEquipes = FEquipes;
    }

    

}
