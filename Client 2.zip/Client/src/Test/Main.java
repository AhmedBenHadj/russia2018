/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

import Entite.Commentaire;
import Entite.Match;
import Entite.Pari;
import Entite.Publication;
import Entite.User;
import Service.ServiceCommentaire;
import Service.ServiceEquipe;
import Service.ServiceMatch;
import Service.ServicePari;
import Service.ServicePublication;
import java.sql.Date;

/**
 *
 * @author Ghassen
 */
public class Main {
    public static void main(String[]arg){
        new ServicePari().updatepari();
       new ServicePari().updateFichePariandUser();
    }
    
}
