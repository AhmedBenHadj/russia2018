/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Fantasy;

import Entite.EquipeFantasy;
import Entite.Joueur;
import Entite.JoueurFantasy;
import Service.ServiceEquipeFantasy;
import Service.ServiceJoueur;
import Service.ServiceJoueurFantasy;
import Utilitaire.Session;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author quickstrikes96
 */
public class AjoutFantasyEquipeController implements Initializable {

    @FXML
    private TextField id_eqF;
    @FXML
    private Button confirmer;
    @FXML
    private Button show;
    @FXML
    private Button cancel;
    @FXML
    private TableView<Joueur> liste_joueurss;
    @FXML
    private TableColumn<JoueurFantasy, String> col1;
    @FXML
    private TableColumn<JoueurFantasy, String> col2;
    @FXML
    private TableColumn<JoueurFantasy, String> col3;
    @FXML
    private TableColumn<JoueurFantasy, String> col4;

    @FXML
    private TableView<Joueur> select_joueurs;
    @FXML
    private TableColumn<Joueur, String> col_prenom;
    @FXML
    private TableColumn<Joueur, String> col_nom;
    @FXML
    private TableColumn<Joueur, String> col_club;
    @FXML
    private TableColumn<Joueur, Integer> col_prix;
    @FXML
    private TableColumn<Joueur, String> col_poste;
    private EquipeFantasy Equi;
    @FXML
    private Button setteam;
    @FXML
    private JFXTextField rech;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    ObservableList<Joueur> data;
    @FXML
    private Button supp;

    @Override

    public void initialize(URL url, ResourceBundle rb) {

        confirmer.setOnAction(this::addnow);

        data = FXCollections.observableArrayList();
        ServiceJoueur SJ = new ServiceJoueur();
        List<Joueur> LJF = SJ.getALL();
        for (Joueur joF : LJF) {
            data.add(new Joueur(joF.getId(), joF.getPrenom(), joF.getNom(), joF.getEquipe(), joF.getPrix(), joF.getPosteF()));
        }

        col_prenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        col_nom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        col_club.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Joueur, String>, ObservableValue<String>>() {
            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Joueur, String> param) {
                return new SimpleStringProperty(param.getValue().getEquipe().getNom());
            }
        });
        col_prix.setCellValueFactory(new PropertyValueFactory<>("prix"));
        col_poste.setCellValueFactory(new PropertyValueFactory<>("posteF"));

        select_joueurs.setItems(data);

    }

    @FXML
    public void addnow(ActionEvent event) {
        EquipeFantasy E = new EquipeFantasy();

        E.setUser(Session.getUser());
        E.setNom(id_eqF.getText());
        new ServiceEquipeFantasy().creer_equipefantasy(E);
        this.Equi = E;
    }

    @FXML
    public void Retour_Acceuil(ActionEvent event) throws IOException {
        /*Parent IMod = FXMLLoader.load(getClass().getResource("acceuil.fxml"));
        Scene IModScene = new Scene(IMod);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(IModScene);
        window.show();*/
    }
    ObservableList<Joueur> test;

    @FXML
    private void afficher(ActionEvent event) {

        Joueur joueur = select_joueurs.getSelectionModel().getSelectedItem();
        System.out.println(joueur);
        test = FXCollections.observableArrayList();

        for (int i = 0; i < liste_joueurss.getItems().size(); i++) {
            test.add(liste_joueurss.getItems().get(i));

        }
        if (test.size() < 15) {
            test.add(joueur);
            select_joueurs.getItems().remove(joueur);
            col1.setCellValueFactory(new PropertyValueFactory<>("prenom"));
            col2.setCellValueFactory(new PropertyValueFactory<>("nom"));
            col3.setCellValueFactory(new PropertyValueFactory<>("prix"));
            col4.setCellValueFactory(new PropertyValueFactory<>("posteF"));

            liste_joueurss.setItems(test);
        }
    }

    @FXML
    private void validerequipe(ActionEvent event) {

        for (Joueur joF : test) {
            if (test.size() == 15) {
                JoueurFantasy J = new JoueurFantasy();
                J.setFEquipes(Equi);
                J.setJoueur(joF);
                J.setEtat(1);
                J.setPoints(0);
                new ServiceJoueurFantasy().ajouter_joueur(J);
                System.out.println("Ajout Joueur Fantasy via INTERFACE effectué");

            } else {
                System.out.println("replay");
            }
        }
    }

    @FXML
    private void researchplayer(javafx.scene.input.KeyEvent event) {

        ServiceJoueur S = new ServiceJoueur();
        System.out.println(data);
        for (Joueur joF : data) {
            if (rech.getText().isEmpty()) {
                data = (ObservableList<Joueur>) S.getALL();
            } else {
                data = (ObservableList<Joueur>) new ServiceJoueur().D_chercher(rech.getText());
            }
        }

    }

    @FXML
    private void deleteplayer(ActionEvent event) {
        Joueur joueur = liste_joueurss.getSelectionModel().getSelectedItem();
        liste_joueurss.getItems().remove(joueur);
    }

}
