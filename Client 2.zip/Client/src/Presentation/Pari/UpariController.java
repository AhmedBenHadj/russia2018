/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Pari;

import Entite.Equipe;
import Entite.FichePari;
import Entite.Match;
import Entite.Pari;
import Service.ServiceEquipe;
import Service.ServiceFichePari;
import Service.ServicePari;
import Service.ServiceUser;
import Utilitaire.Session;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ListView;

/**
 * FXML Controller class
 *
 * @author skanderbejaoui
 */
public class UpariController implements Initializable {

    @FXML
    private ListView<FichePari> list;
    ObservableList observableList = FXCollections.observableArrayList();
    @FXML
    private ChoiceBox<String> choix;
    @FXML
    private JFXButton afficher_mes_paris;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        choix.getItems().add("Afficher les paris gagnés");
        choix.getItems().add("Afficher les paris perdus");
        choix.getItems().add("Afficher les paris en cours");
    }

    @FXML
    private void afficher_mes_paris(ActionEvent event) {
        list.getItems().clear();

        FichePari fp = new FichePari();
        fp.setU(Session.getUser());
        ServicePari sp = new ServicePari();
        ServiceFichePari sfp = new ServiceFichePari();
        List<Integer> listee = sfp.get_idPari();
        for (Integer integer : listee) {
            //fp.getU().setId(u.getId());
            fp.setU(Session.getUser());
            fp = sfp.affichertousFP(integer, fp.getU().getId());
            for (Pari pari : fp.getParis()) {
                observableList.add(pari.toString1() + fp.toString());

            }
        }
        list.setItems(observableList);
        int idmatch=1;
        Match m = new Match();
        m.setId(idmatch);
        List<Pari> lp = new ArrayList<>();
        for (Pari pari :  (sp.afficher_etat_pari(Pari.EtatPari.Encours))) {
            if(pari.getM().getId()==idmatch)
                lp.add(pari);
        }
        ServiceUser su = new ServiceUser();
        ServiceEquipe se = new ServiceEquipe();
        Equipe e = se.gagnant(m);
      /* 
        for (Pari pari : lp) {
            System.out.println(pari.getM());
            if(pari.getResultat().equals(Pari.ResultatPari.un)&& (e.getId()==m.getE1().getId())){
                pari.setEtat(Pari.EtatPari.Gagne);
                sp.modifierPari(pari);
                Session.getUser().setJeton(Session.getUser().getJeton()+Float.parseFloat(pari.getGain().getText()));
                su.update(Session.getUser());
            }
            else if(pari.getResultat().equals(Pari.ResultatPari.deux)&&(e.getId()==m.getE2().getId())){
                pari.setEtat(Pari.EtatPari.Gagne);
                 sp.modifierPari(pari);
                Session.getUser().setJeton(Session.getUser().getJeton()+Float.parseFloat(pari.getGain().getText()));
                su.update(Session.getUser());
            }
            else if(pari.getResultat().equals(Pari.ResultatPari.x)&&(e == null)){
                pari.setEtat(Pari.EtatPari.Gagne);
                 sp.modifierPari(pari);
                Session.getUser().setJeton(Session.getUser().getJeton()+Float.parseFloat(pari.getGain().getText()));
                su.update(Session.getUser());
            }
            else{
                pari.setEtat(Pari.EtatPari.Perdu);
                sp.modifierPari(pari);
            }
        }*/
      
                
       
    }
}
