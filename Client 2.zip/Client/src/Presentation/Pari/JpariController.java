/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Pari;

import Entite.FichePari;
import Entite.Match;
import Entite.User;
import Service.ServiceFichePari;
import Service.ServicePari;
import Utilitaire.FXMLHandler;
import Utilitaire.Session;
import java.net.URL;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author skanderbejaoui
 */
public class JpariController implements Initializable {

    @FXML
    private TableView<Match> table;
    @FXML
    private TableColumn<Match, String> e1;
    @FXML
    private TableColumn<Match, String> e2;
    @FXML
    private TableColumn<Match, Float> c1;
    @FXML
    private TableColumn<Match, Float> cn;
    @FXML
    private TableColumn<Match, Float> c2;
    private ObservableList<Match> data;
    private ToggleButton button11;
    private ToggleButton button22;
    private ToggleButton button33;
    @FXML
    private TextField mise;
    @FXML
    private Label gain;
    @FXML
    private Button valider;
    @FXML
    private Label cote;
    
    private static AnchorPane test;

    public static AnchorPane getTest() {
        return test;
    }

    public static void setTest(AnchorPane test) {
        JpariController.test = test;
    }
    

    private float somme_cote=1 ;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        gain.setText("0");
        data = FXCollections.observableArrayList();
        ServicePari sp = new ServicePari();
        List<Integer> listee = sp.get_idMatch();
        for (Integer integer : listee) {

            Match M = sp.get_Match_PariJ(integer);
            if (M != null) {
                M.setId(integer);
                data.add(new Match((M.getE1().getNom()), M.getE2().getNom(), M.getCote_eq1(), M.getCote_nul(), M.getCote_eq2(), M.getId()));
                M.setNom1(M.getE1().getNom());
                M.setNom2(M.getE2().getNom());
                button11 = new ToggleButton(String.valueOf(M.getCote_eq1()));
                M.setButton1(button11);
                button22 = new ToggleButton(String.valueOf(M.getCote_nul()));
                M.setButton2(button22);
                button33 = new ToggleButton(String.valueOf(M.getCote_eq2()));
                M.setButton3(button33);
                e1.setCellValueFactory(new PropertyValueFactory<>("nom1"));
                e2.setCellValueFactory(new PropertyValueFactory<>("nom2"));
                c1.setCellValueFactory(new PropertyValueFactory<>("button1"));
                cn.setCellValueFactory(new PropertyValueFactory<>("button2"));
                c2.setCellValueFactory(new PropertyValueFactory<>("button3"));
            }
        }
        if (data != null) {
            table.setItems(null);
            table.setItems(data);
        }

        for (Match match : data) {
         
            List<Float> list = new ArrayList<>();
            match.getButton1().setOnAction(e -> {

                if (match.getButton1().isSelected()) {
                    match.getButton2().setDisable(true);
                    match.getButton3().setDisable(true);
                    somme_cote*=Float.parseFloat(match.getButton1().getText());
                  cote.setText(String.valueOf(somme_cote));
                }
                else{
                     match.getButton2().setDisable(false);
                    match.getButton3().setDisable(false);
                somme_cote/=Float.parseFloat(match.getButton1().getText());
                  if(somme_cote==1){
                          cote.setText("0.00");
                     }
                     else{
         cote.setText(String.valueOf(somme_cote));  
                     }    
                }

            });
            match.getButton2().setOnAction(e -> {

                if (match.getButton2().isSelected()) {
                      match.getButton1().setDisable(true);
                    match.getButton3().setDisable(true);
        somme_cote*=Float.parseFloat(match.getButton2().getText());
         cote.setText(String.valueOf(somme_cote));       
                }
                 else{
                     match.getButton1().setDisable(false);
                    match.getButton3().setDisable(false);
                     somme_cote/=Float.parseFloat(match.getButton2().getText());
                      if(somme_cote==1){
                          cote.setText("0.00");
                     }
                     else{
         cote.setText(String.valueOf(somme_cote));  
                     }   
                   
                }
            });
            match.getButton3().setOnAction(e -> {

                if (match.getButton3().isSelected()) {
                      match.getButton1().setDisable(true);
                    match.getButton2().setDisable(true);
                 somme_cote*=Float.parseFloat(match.getButton3().getText());
                 cote.setText(String.valueOf(somme_cote));  
                
                }
                 else{
                     match.getButton1().setDisable(false);
                    match.getButton2().setDisable(false);
                     somme_cote/=Float.parseFloat(match.getButton3().getText());
                     if(somme_cote==1){
                          cote.setText("0.00");
                     }
                     else{
         cote.setText(String.valueOf(somme_cote));  
                     }
                
                }
            });
          
            mise.setOnKeyReleased(new EventHandler<KeyEvent>() {
                public void handle(KeyEvent e) {
                    Float t = somme_cote*Float.parseFloat(mise.getText());
                   
                    gain.setText(String.valueOf(t));
                }
            });

        }
    }

    
    @FXML
    public void valider(ActionEvent event){
        ServiceFichePari sfp = new ServiceFichePari();
        ServicePari sp = new ServicePari();
        FichePari fp = new FichePari();
        fp.setU(Session.getUser());
        fp.setCote_total(Float.parseFloat(cote.getText()));
        fp.setEtat(FichePari.EtatFiche.Encours);
        fp.setMisetotal(Float.parseFloat(mise.getText()));
        fp.setDate(new Date(System.currentTimeMillis()));
        fp.setGain(Float.parseFloat(gain.getText()));
       
   
         sfp.ajouterfichepariJ(fp);
    
    }

    @FXML
    private void retour(ActionEvent event) {
        FXMLHandler.afficherFXML(test, "/Presentation/Pari/pari.fxml");
    }
    
    
}
