/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Matchs;

import Configuration.MyConnexion;
import Entite.Equipe;
import Entite.Groupe;
import Entite.Match;
import Entite.Match.EtatMatch;
import Entite.Match.progress;
import Entite.Score;
import Entite.Stade;
import Service.ServiceEquipe;
import Service.ServiceGroupe;
import Service.ServiceMatch;
import Service.ServiceScore;
import Service.ServiceStade;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTimePicker;
import java.net.URL;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;


/**
 * FXML Controller class
 *
 * @author hseli
 */
public class FormulaireAjoutMatchController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @FXML
    private ComboBox id_groupe;
    
    @FXML
    private ComboBox id_equipe_1;
    
    @FXML
    private ComboBox id_equipe_2;
    
    @FXML
    private ComboBox id_stade;
    
    private Match match;
    @FXML
    private ComboBox id_etat;
    
    @FXML
    private TextField id_nombre_spectateur;
    
    @FXML
    private Button id_ajouter;
    @FXML
    private DatePicker id_date;
    @FXML
    private JFXTimePicker id_time;
    @FXML
    private ComboBox<Enum> id_type;
    @FXML
    private JFXButton id_load;
    
    
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       
        fillCombo();
        id_ajouter.setOnAction(this::ajouter);
        id_load.setOnAction(this::afficher);
        
    }
    public void afficher(ActionEvent event){
         ObservableList<String> data_Eq1 = FXCollections.observableArrayList();
         ObservableList<String> data_Eq2 = FXCollections.observableArrayList();
         
         ServiceMatch S=new ServiceMatch();
         ServiceEquipe SE=new ServiceEquipe();
        // match=S.get((Integer)this.id_groupe.getValue());
         List<Equipe> LM=SE.get_by_group((String)this.id_groupe.getValue());
         Equipe E=new Equipe();
         for (Equipe equipe1 : LM) {
            data_Eq1.add(equipe1.getNom());
            data_Eq2.add(equipe1.getNom());
             
             //A regler 
        }
          
       
        id_equipe_1.setItems(data_Eq1);
        
        id_equipe_2.setItems(data_Eq2);
    }
            
    public void fillCombo(){
        ObservableList<String> data = FXCollections.observableArrayList();
      
        ObservableList<String> data_St = FXCollections.observableArrayList();
        ObservableList<Enum> data_Et = FXCollections.observableArrayList();
        ObservableList<Enum> data_Pro = FXCollections.observableArrayList();
        ServiceGroupe SG=new ServiceGroupe();
      
        List<Groupe> LG = SG.get_Groupe();
        for (Groupe groupe : LG) {
            data.add(groupe.getNom());
        }
        id_groupe.setItems(null);
        id_groupe.setItems(data);
        
        
        
        ServiceStade SS=new ServiceStade();
        List<Stade> LS=SS.get_Stade();
        for (Stade stade : LS) {
            data_St.add(stade.getNom());
        }
        id_stade.setItems(null);
        id_stade.setItems(data_St);
       
        data_Et.add(Match.EtatMatch.Debut);
       
        data_Pro.add(Match.progress.pool);
          
        id_etat.setItems(data_Et);
        id_type.setItems(null);
        id_type.setItems(data_Pro);
    }
    
    @FXML
    private void ajouter(ActionEvent event) {
        try{
        ServiceEquipe SE=new ServiceEquipe();
        ServiceGroupe SG=new ServiceGroupe();
        ServiceStade SS=new ServiceStade();
        ServiceScore SC=new ServiceScore();
        ServiceMatch SM=new ServiceMatch();
         Score S=new Score();
         Match M = new Match();
         M.setG(SG.get(SG.recuperer_Id_par_nom((String)id_groupe.getValue())));
         M.setE1(SE.get(SE.recuperer_Id_par_nom((String)id_equipe_1.getValue())));
         M.setE2(SE.get(SE.recuperer_Id_par_nom((String)id_equipe_2.getValue())));
         M.setS(SS.get(SS.recuperer_Id_par_nom((String)id_stade.getValue())));
         M.setDate(Date.valueOf(id_date.getValue()));
         M.setHeure(Time.valueOf(id_time.getValue()));
         M.setEtat((EtatMatch)id_etat.getValue());
         M.setType((progress)id_type.getValue());
         M.setNombre_spectateur(Integer.parseInt(id_nombre_spectateur.getText()));
         SM.ajouter_Match(M);
         S.setId(M.getId());
         S.setA(0);
         S.setB(0);
         SC.ajouter_Score(S);
         
         
        }catch(StackOverflowError e){
            
        }

    }
    
}
