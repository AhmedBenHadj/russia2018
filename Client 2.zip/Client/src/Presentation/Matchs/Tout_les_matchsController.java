/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Matchs;

import Entite.Evenement;
import Entite.Match;
import Entite.Score;
import Service.ServiceEquipe;
import Service.ServiceEvenement;
import Service.ServiceMatch;
import Service.ServiceScore;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author eloss
 */
public class Tout_les_matchsController implements Initializable {
    @FXML
    private AnchorPane id_colMatch;
    @FXML
    private TableView<Match> id_Matchs;
    @FXML
    private TableColumn<Match, String> id_date;
    @FXML
    private TableColumn<Match, String> id_time;
    @FXML
    private TableColumn<Match, String> id_equipe_1;
    @FXML
    private TableColumn<Match, String> id_score;
    @FXML
    private TableColumn<Match, String> id_equipe_2;
    @FXML
    private TableColumn<Match, String> id_stade;
    

    private ObservableList<Match> data;
    
    private ObservableList<Score> dataS;
    @FXML
    private JFXButton id_load;
    @FXML
    private JFXButton id_event;
   
    
    private ObservableList<Evenement> data1;
    @FXML
    private TableView<Evenement> table_event;
    @FXML
    private TableColumn<Evenement, String> id_joueur_event;
    @FXML
    private TableColumn<Evenement, Integer> id_but_event;
    @FXML
    private TableColumn<Evenement, String> id_carton_event;
    @FXML
    private TableColumn<Evenement, Integer> id_temps_event;
    @FXML
    private TableColumn<Evenement, String> match_id;

    /**
     * Initializes the controller class.
     */
    //Afficher l'interface de moderateur
   /* @FXML
    public void afficherInterModer(ActionEvent event) throws IOException {
        Parent IMod = FXMLLoader.load(getClass().getResource("InterfaceModerateur.fxml"));
        Scene IModScene = new Scene(IMod);

        //This line get the stage information
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(IModScene);
        window.show();
    }*/

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        id_load.setOnAction(this::fillTable);
        recuperer_Id();
        //insererCheckBox();
    }

    private void fillTable(ActionEvent event) {
        data = FXCollections.observableArrayList();
        dataS = FXCollections.observableArrayList();
        ServiceMatch SM = new ServiceMatch();
        ServiceEquipe SE = new ServiceEquipe();
        ServiceScore SS=new ServiceScore();
        
        List<Match> LM = SM.get_Match();
        Match M = new Match();
        for (Match match : LM) {   
            Score LS=SS.get(match.getId());
            match.setScore1(LS);
            data.add(new Match(match.getId(), match.getDate(), match.getHeure(), match.getE1(), match.getScore1(), match.getE2(), match.getS()));
        }
        id_date.setCellValueFactory(new PropertyValueFactory<>("Date"));
        id_time.setCellValueFactory(new PropertyValueFactory<>("heure"));

        id_equipe_1.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Match, String>, ObservableValue<String>>() {

            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Match, String> param) {
                return new SimpleStringProperty(param.getValue().getE1().getNom());
            }
        });
        id_equipe_2.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Match, String>, ObservableValue<String>>() {

            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Match, String> param) {
                return new SimpleStringProperty(param.getValue().getE2().getNom());
            }
        });
        id_stade.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Match, String>, ObservableValue<String>>() {

            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Match, String> param) {
                return new SimpleStringProperty(param.getValue().getS().getNom());
            }
        });
           
            id_score.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Match, String>, ObservableValue<String>>() {

            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Match, String> param) {
                return new SimpleStringProperty(String.valueOf("    "+param.getValue().getScore1().getA())+"    -    "+String.valueOf(param.getValue().getScore1().getB()));
            }
        });
        
       
       /* id_score.setCellValueFactory(new Callback<TableColum.CellDataFeatures<Match,String>,ObservableValue<String>>(){

                @Override
                public ObservableValue<String> call(CellDataFeatures<Match, String> param) {
                    return new SimpleStringProperty(String.valueOf(param.getValue().getScore1().getA())+"-"+String.valueOf(param.getValue().getScore1().getB()));
                }
            });*/

        id_Matchs.setItems(null);
        id_Matchs.setItems(data);
        
        /*for (Match item : id_Matchs.getItems()) {
            
        }*/

    }

    private void recuperer_Id() {
        data1 = FXCollections.observableArrayList();
        /*ServiceEvenement SE=new ServiceEvenement();
        List<Evenement> LE=SE.get_Evenement();
        for (Evenement evenement : LE) {
            data1.add(new Evenement(evenement.getM(),evenement.getJoueur(),evenement.getCarton(),evenement.getBut(),evenement.getTemps()));
        }*/
       

        id_Matchs.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                data1.clear();
                Match m = new Match();
                int id = id_Matchs.getItems().get(id_Matchs.getSelectionModel().getSelectedIndex()).getId();
                //System.out.println(id);
                //Match M=id_Matchs.getItems().get(id_Matchs.getSelectionModel().getSelectedIndex());
                Evenement E=new Evenement();
                
                ServiceEvenement SE = new ServiceEvenement();
                List<Evenement> LE = SE.get_Event_Par_ID(id);
                for (Evenement evenement : LE) {
                    data1.add(new Evenement(evenement.getM(), evenement.getJoueur(), evenement.getCarton(), evenement.getBut(), evenement.getTemps()));
                }
                id_but_event.setCellValueFactory(new PropertyValueFactory<>("but"));
                
                id_carton_event.setCellValueFactory(new PropertyValueFactory<>("carton"));
                
                id_temps_event.setCellValueFactory(new PropertyValueFactory<>("temps"));
                match_id.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Evenement, String>, ObservableValue<String>>() {

                    @Override
                    public ObservableValue<String> call(TableColumn.CellDataFeatures<Evenement, String> param) {
                     
                        return new SimpleStringProperty(String.valueOf(param.getValue().getJoueur().getJ().getEquipe().getNom()));
                        //param.getValue().getM().getNom()
                       
                    }
                

                });
                id_joueur_event.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Evenement, String>, ObservableValue<String>>() {

            @Override
            public ObservableValue<String> call(TableColumn.CellDataFeatures<Evenement, String> param) {
                return new SimpleStringProperty(param.getValue().getJoueur().getJ().getNom());
            }
        });
                
                table_event.setItems(data1);

            }
        });
      
    }
    /*private void insererCheckBox(){
        TableColumn select = new TableColumn("CheckBox");
        select.setMinWidth(200);
        select.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Match, CheckBox>, ObservableValue<CheckBox>>() {

            @Override
            public ObservableValue<CheckBox> call(
                    TableColumn.CellDataFeatures<Match, CheckBox> arg0) {
                 Match match = arg0.getValue();

                CheckBox checkBox = new CheckBox();

                checkBox.selectedProperty().setValue(match.isIsSelected());



                checkBox.selectedProperty().addListener(new ChangeListener<Boolean>() {
                    public void changed(ObservableValue<? extends Boolean> ov,
                            Boolean old_val, Boolean new_val) {

                        match.setIsSelected(new_val);

                    }
                });

                return new SimpleObjectProperty<CheckBox>(checkBox);

            }

        });
        id_Matchs.getColumns().addAll(select);
    }*/

}
