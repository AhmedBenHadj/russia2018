/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Joueur_P;

import Entite.Equipe;
import Entite.Joueur;
import Entite.Joueur_P;
import Service.ServiceEquipe;
import Service.ServiceJoueur;
import Service.ServiceJoueur_P;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author hseli
 */
public class FormulaireAjoutJoueur_PController implements Initializable {

    @FXML
    private JFXComboBox<String> id_joueur;
    @FXML
    private JFXTextField id_temps_joue;
    @FXML
    private JFXButton id_ajouter;
    @FXML
    private JFXComboBox<String> id_equipe;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        fillCombo();
        id_equipe.setOnAction(this::afficher_J);
        id_ajouter.setOnAction(this::ajouter);
    }    
    public void fillCombo(){
        ObservableList<String> data1 = FXCollections.observableArrayList();
        ServiceEquipe SE=new ServiceEquipe();
        List<Equipe> LE=SE.getALL();
        for (Equipe equipe : LE) {
            data1.add(equipe.getNom());
        }
        id_equipe.setItems(data1);     
    }
    public void afficher_J(ActionEvent event){
        ObservableList<String> data_J = FXCollections.observableArrayList();
        ServiceJoueur SJ=new ServiceJoueur();
        ServiceEquipe SE=new ServiceEquipe();
        List<Joueur> LS=SJ.recuperer_Par_Nom_Eq(this.id_equipe.getValue());
        for (Joueur joueur : LS) {
            data_J.add(joueur.getNom()/*+" "+joueur.getPrenom()*/);
        }
        id_joueur.setItems(data_J);
    }
    public void ajouter(ActionEvent event){
        ServiceJoueur_P SJP=new ServiceJoueur_P();
        ServiceJoueur SJ=new ServiceJoueur();
        Joueur_P JP=new Joueur_P();
        JP.setJ(SJ.get(SJ.recuperer_Id_par_nom(this.id_joueur.getValue())));
        JP.setTemps_joue(Integer.parseInt(id_temps_joue.getText()));
        SJP.ajouter_JoueurP(JP);
    }
}
