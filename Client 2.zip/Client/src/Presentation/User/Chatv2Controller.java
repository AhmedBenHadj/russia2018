/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.User;

import Utilitaire.Session;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class Chatv2Controller implements Initializable {

    @FXML
    private AnchorPane chat;
    @FXML
    private JFXTextArea textarea;
    @FXML
    private JFXTextField inputtext;

    String address = "localhost";
    ArrayList<String> users = new ArrayList();
    int port = 2222;
    Boolean isConnected = false;
    Socket sock;
    BufferedReader reader;
    PrintWriter writer;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        if (Session.getUser() != null) {
            chatLogin();
        }
    }

    @FXML
    private void EnterSend(KeyEvent event) {
        if (event.getCode().equals(KeyCode.ENTER)) {
            sendchat();
        }
    }

    @FXML
    private void send(ActionEvent event) {
        System.out.println("3asba");
        Disconnect2();
        //sendchat();
    }

    public void userAdd(String data) {
        users.add(data);
    }

    public void userRemove(String data) {
        textarea.appendText(data + " is now offline.\n");
    }

    public void writeUsers() {
        String[] tempList = new String[(users.size())];
        users.toArray(tempList);
    }

    public void ListenThread() {
        Thread IncomingReader = new Thread(new IncomingReader());
        IncomingReader.start();
    }

    public void Disconnect1() {
        try {
            textarea.appendText("Disconnected.\n");
            sock.close();
        } catch (IOException ex) {
            textarea.appendText("\"Failed to disconnect. \\n\"");
        }
        isConnected = false;
    }

    public void sendDisconnect() {
        String bye = (Session.getUser().getUsername() + ": :Disconnect");
        try {
            writer.println(bye);
            writer.flush();
        } catch (Exception e) {
            textarea.appendText("Could not send Disconnect message.\n");
        }
    }

    public void Disconnect2() {
        if (isConnected) {
            sendDisconnect();
            Disconnect1();
        }
    }

    public class IncomingReader implements Runnable {

        @Override
        public void run() {
            String[] data;
            String stream, done = "Done", connect = "Connect", disconnect = "Disconnect", chat = "Chat";

            try {
                while ((stream = reader.readLine()) != null) {
                    data = stream.split(":");
                    for (String string : data) {
                        System.out.println(string);
                    }
                    if (data[2].equals(chat)) {
                        textarea.appendText(data[0] + ": " + data[1] + "\n");
                        textarea.setScrollTop(textarea.getText().length());
                    } else if (data[2].equals(connect)) {
                        userAdd(data[0]);
                    } else if (data[2].equals(disconnect)) {
                        userRemove(data[0]);
                    } else if (data[2].equals(done)) {
                        writeUsers();
                        users.clear();
                    }
                }
            } catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    private void sendchat() {
        if ((inputtext.getText()).equals("")) {
            inputtext.setText("");
            inputtext.requestFocus();
        } else {
            try {
                writer.println(Session.getUser().getUsername() + ":" + inputtext.getText() + ":" + "Chat");
                writer.flush(); // flushes the buffer
            } catch (Exception ex) {
                textarea.appendText("Message was not sent. \n");
            }
            inputtext.setText("");
            inputtext.requestFocus();
        }

    }

    public void chatLogin() {
        if (isConnected == false) {
            String busername;
            String me = Session.getUser().getUsername();
            busername = me;
            try {
                sock = new Socket(address, port);
                InputStreamReader streamreader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(streamreader);
                writer = new PrintWriter(sock.getOutputStream());
                writer.println(me + ":has connected.:Connect");
                writer.flush();
                isConnected = true;
            } catch (IOException ex) {
                textarea.appendText("Cannot Connect! Try Again. \n");
            }
            ListenThread();
        } else if (isConnected == true) {
            textarea.appendText("You are already connected. \n");
        }
    }
}
