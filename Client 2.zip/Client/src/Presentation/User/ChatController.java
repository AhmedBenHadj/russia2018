/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.User;

import TCPClient.ImageReceiver;
import TCPClient.ImageSender;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.URL;
import java.util.ArrayList;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class ChatController implements Initializable {
    String busername, address = "localhost";
    ArrayList<String> users = new ArrayList();
    int bort = 2222;
    Boolean isConnected = false;

    Socket sock;
    BufferedReader reader;
    PrintWriter writer;
    public void ListenThread() {
        Thread IncomingReader = new Thread(new IncomingReader());
        IncomingReader.start();
    }
    public void userAdd(String data) {
        users.add(data);
    }
    public void userRemove(String data) {
        text.appendText(data + " is now offline.\n");
    }
    public void writeUsers() {
        String[] tempList = new String[(users.size())];
        users.toArray(tempList);
    }
    public void sendDisconnect() {
        String bye = (busername + ": :Disconnect");
        try {
            writer.println(bye);
            writer.flush();
        } catch (Exception e) {
            text.appendText("Could not send Disconnect message.\n");
        }
    }
    public class IncomingReader implements Runnable {

        @Override
        public void run() {
            String[] data;
            String stream, done = "Done", connect = "Connect", disconnect = "Disconnect", chat = "Chat";

            try {
                while ((stream = reader.readLine()) != null) {
                    data = stream.split(":");

                    if (data[2].equals(chat)) {
                        text.appendText(data[0] + ": " + data[1] + "\n");
                        text.setScrollTop(text.getText().length());
                    } else if (data[2].equals(connect)) {
                        userAdd(data[0]);
                    } else if (data[2].equals(disconnect)) {
                        userRemove(data[0]);
                    } else if (data[2].equals(done)) {
                        writeUsers();
                        users.clear();
                    }
                }
            } catch (IOException ex) {
            }
        }
    }
    
    
    @FXML
    private JFXButton aLogin;
    @FXML
    private JFXButton disconnect;
    @FXML
    private JFXButton send;
    @FXML
    private JFXTextField in;

    @FXML
    private JFXTextArea text;
    
    @FXML
    public void Disconnect() {
        try {
            text.appendText("Disconnected.\n");
            sock.close();
        } catch (IOException ex) {
            text.appendText("\"Failed to disconnect. \\n\"");
        }
        isConnected = false;
    }
    
    private void upload(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                new FileChooser.ExtensionFilter("All Files", "*.*"));
        File selectedFile = fileChooser.showOpenDialog(aLogin.getScene().getWindow());
        if (selectedFile != null) {
            ImageSender ic = new ImageSender("localhost", 1988, selectedFile.getAbsoluteFile());
            ImageReceiver.get();
        }
    }
    

    @FXML
    void ALogin(ActionEvent event) {
        if (isConnected == false) {
            String me = "ghassen";
            Random generator = new Random();
            int i = generator.nextInt(999) + 1;
            String is = String.valueOf(i);
            me = me.concat(is);
            busername = me;
            try {
                sock = new Socket(address, bort);
                InputStreamReader streamreader = new InputStreamReader(sock.getInputStream());
                reader = new BufferedReader(streamreader);
                writer = new PrintWriter(sock.getOutputStream());
                writer.println(me + ":has connected.:Connect");
                writer.flush();
                isConnected = true;
            } catch (IOException ex) {
                text.appendText("Cannot Connect! Try Again. \n");
            }
            ListenThread();
        } else if (isConnected == true) {
            text.appendText("You are already connected. \n");
        }
    }
    
    
    void Disconnect(ActionEvent event) {
        if (isConnected) {
            sendDisconnect();
            Disconnect();
        }
    }
    @FXML
    void Send(ActionEvent event) {
        if ((in.getText()).equals("")) {
            in.setText("");
            in.requestFocus();
        } else {
            try {
                writer.println(busername + ":" + in.getText() + ":" + "Chat");
                writer.flush(); // flushes the buffer
            } catch (Exception ex) {
                text.appendText("Message was not sent. \n");
            }
            in.setText("");
            in.requestFocus();
        }
    }
    
    
    
    
    
    
    
    
    
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
