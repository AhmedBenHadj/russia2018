/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.User;

import Entite.User;
import Service.ServiceUser;
import static Service.ServiceUser.VALID_EMAIL_ADDRESS_REGEX;
import Utilitaire.MD5;
import Utilitaire.Password;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.KeyEvent;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class Ajouter_ModerateurController implements Initializable {

    @FXML
    private JFXTextField nom;
    @FXML
    private JFXTextField prenom;
    @FXML
    private JFXTextField username;
    @FXML
    private JFXTextField email;
    @FXML
    private JFXPasswordField mdp;
    @FXML
    private JFXPasswordField rmdp;
    @FXML
    private JFXButton ajoter;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.ajoter.setDisable(true);
    }

    @FXML
    private void reset(ActionEvent event) {
        this.nom.setText("");
        this.email.setText("");
        this.mdp.setText("");
        this.prenom.setText("");
        this.rmdp.setText("");
        this.username.setText("");
        this.ajoter.setDisable(true);
    }

    @FXML
    private void ajouter(ActionEvent event) {
        ServiceUser su = new ServiceUser();
        User u = new User();
        u.setConnecte(User.Connecte.OFF);
        u.setDate_creation(new Date(System.currentTimeMillis()));
        u.setEmail(email.getText());
        u.setEtat(1);
        u.setImage("");
        u.setJeton(100);
        u.setMdp(Password.hashPassword(mdp.getText()));
        u.setNom(nom.getText());
        u.setPrenom(prenom.getText());
        u.setRole(User.Role.moderateur);
        u.setType(1);
        u.setUsername(username.getText());
        u.setConfirmkey(MD5.generateKey(mdp.getText()));
        u.setImage("PROFILEDEFAULT.png");
        su.create(u);
    }

    @FXML
    private void check(KeyEvent event) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(email.getText());
        if (!this.email.getText().equals("")
                && !this.mdp.getText().equals("")
                && !this.nom.getText().equals("")
                && !this.prenom.getText().equals("")
                && !this.prenom.getText().equals("")
                && !this.rmdp.getText().equals("")
                && !this.username.getText().equals("")
                && (this.mdp.getText().equals(this.rmdp.getText()))
                && matcher.find()) {
            this.ajoter.setDisable(false);
        } else {
            this.ajoter.setDisable(true);
        }
    }

}
