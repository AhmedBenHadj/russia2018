/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.User;

import Entite.User;
import Service.ServiceUser;
import Utilitaire.Password;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class LoginController implements Initializable {

    @FXML
    private JFXTextField user_email;

    @FXML
    private JFXPasswordField mdp;

    @FXML
    private void reset(ActionEvent event) {
        this.mdp.setText("");
        this.user_email.setText("");
    }

    @FXML
    private void login(ActionEvent event) {
        if(this.user_email.getText().equals(""))return;
        if(this.mdp.getText().equals(""))return;
        ServiceUser su = new ServiceUser();
        User u = su.retrieveEmail(this.user_email.getText());
        if(u!=null&&Password.checkPassword(mdp.getText(), u.getMdp())){
            connect(u);
        }else{
            u=su.retrieveUsername(this.user_email.getText());
            if(u!=null&&Password.checkPassword(mdp.getText(), u.getMdp())){
                connect(u);
            }else{
                System.out.println("nooo");
            }
        }
    }
    private void connect(User u){
        ServiceUser su = new ServiceUser();
        u.setConnecte(User.Connecte.ON);
        su.update(u);
        System.out.println("connecte");
    }

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    
    
}
