/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.User;

import Entite.User;
import Service.ServiceUser;
import static Service.ServiceUser.VALID_EMAIL_ADDRESS_REGEX;
import Utilitaire.Password;
import Utilitaire.Session;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class ProfilController implements Initializable {

    @FXML
    private Label username;
    @FXML
    private Label role;
    @FXML
    private Label type;
    @FXML
    private Label jeton;
    @FXML
    private JFXTextField email;
    @FXML
    private JFXTextField nom;
    @FXML
    private JFXTextField prenom;
    @FXML
    private JFXPasswordField mdp;
    @FXML
    private JFXPasswordField rmdp;
    @FXML
    private JFXButton reset;
    @FXML
    private JFXButton confirmer;
    @FXML
    private Rectangle rc;
    private File image;
    @FXML
    private JFXPasswordField n2;
    @FXML
    private JFXPasswordField n1;
    @FXML
    private JFXButton reset1;
    @FXML
    private JFXButton confirmer1;

    public void setUser(User user) {
        
    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ServiceUser su = new ServiceUser();
        this.username.setText(Session.getUser().getUsername());
        this.role.setText(Session.getUser().getRole().toString());
        this.type.setText(String.valueOf(Session.getUser().getType()));
        this.jeton.setText(String.valueOf(Session.getUser().getJeton()));
        this.email.setText(Session.getUser().getEmail());
        this.nom.setText(Session.getUser().getNom());
        this.prenom.setText(Session.getUser().getPrenom());
        Image i;
        if (Session.getUser().getImage().equals("PROFILEDEFAULT")) {
             i = new Image("/image/PROFILEDEFAULT.png");
        } else {
             i = new Image("/image/" + Session.getUser().getImage());
        }
        if (i == null) {
            i = new Image("/image/PROFILEDEFAULT.png");
        }
        rc.setFill(new ImagePattern(i));
        this.rc.setOnMouseClicked((MouseEvent e) -> {
            if (e.getClickCount() == 2) {
                FileChooser fileChooser = new FileChooser();
                fileChooser.setTitle("Open Resource File");
                fileChooser.getExtensionFilters().addAll(
                        new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                        new FileChooser.ExtensionFilter("All Files", "*.*"));
                File selectedFile = fileChooser.showOpenDialog(email.getScene().getWindow());
                if (selectedFile != null) {
                    ProfilController.this.image = selectedFile;
                    Image ij = new Image(selectedFile.toURI().toString());
                    ProfilController.this.rc.setFill(new ImagePattern(ij));
                }
            }
        });
    }

    @FXML
    private void reset(ActionEvent event) {
        this.email.setText(Session.getUser().getUsername());
        this.nom.setText(Session.getUser().getNom());
        this.prenom.setText(Session.getUser().getPrenom());
        this.mdp.setText("");
        this.rmdp.setText("");
    }

    @FXML
    private void confirmer(ActionEvent event) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(email.getText());
        if (this.nom.getText().equals("")) {
            return;
        }
        if (this.prenom.getText().equals("")) {
            return;
        }
        if (this.mdp.getText().equals("")) {
            return;
        }
        if (this.rmdp.getText().equals("")) {
            return;
        }
        if (!this.mdp.getText().equals(this.rmdp.getText())) {
            return;
        }
        if (!Password.checkPassword(this.mdp.getText(), Session.getUser().getMdp())) {
            return;
        }
        if (!matcher.find()) {
            return;
        }
        ServiceUser su = new ServiceUser();
        User user = Session.getUser();
        user.setNom(this.nom.getText());
        user.setPrenom(this.prenom.getText());
        user.setEmail(this.email.getText());
        su.update(user);
        Session.setUser(user);
    }

    @FXML
    private void reset1(ActionEvent event) {
        this.n1.setText("");
        this.n2.setText("");
    }

    @FXML
    private void confirmer1(ActionEvent event) {
        if(this.n1.getText().equals(""))return;
        if(this.n2.getText().equals(""))return;
        if(!Password.checkPassword(this.n2.getText(), Session.getUser().getMdp()))return;
        User user=Session.getUser();
        user.setMdp(Password.hashPassword(this.n1.getText()));
        ServiceUser su = new ServiceUser();
        su.update(user);
        Session.setUser(user);
    }

}
