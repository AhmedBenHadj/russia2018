/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.User;

import Entite.User;
import Service.ServiceUser;
import static Service.ServiceUser.VALID_EMAIL_ADDRESS_REGEX;
import TCPClient.ImageReceiver;
import TCPClient.ImageSender;
import Utilitaire.*;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.input.KeyEvent;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class Demande_JournalisteController implements Initializable {

    @FXML
    private JFXTextField nom;
    @FXML
    private JFXTextField prenom;
    @FXML
    private JFXTextField username;
    @FXML
    private JFXTextField email;
    @FXML
    private JFXPasswordField mdp;
    @FXML
    private JFXPasswordField rmdp;

    private File image;
    @FXML
    private JFXButton ajoter;
    @FXML
    private Rectangle r;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        image = null;
        this.ajoter.setDisable(true);
    }

    @FXML
    private void upload(ActionEvent event) {

        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open Resource File");
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                new FileChooser.ExtensionFilter("All Files", "*.*"));
        File selectedFile = fileChooser.showOpenDialog(email.getScene().getWindow());
        if (selectedFile != null) {
            this.image = selectedFile;            
        }
    }

    @FXML
    private void reset(ActionEvent event) {
        this.nom.setText("");
        this.email.setText("");
        this.image = null;
        this.mdp.setText("");
        this.prenom.setText("");
        this.rmdp.setText("");
        this.username.setText("");
        this.ajoter.setDisable(true);
    }

    @FXML
    private void ajouter(ActionEvent event) {
        ServiceUser su = new ServiceUser();
        User u = new User();
        u.setConnecte(User.Connecte.OFF);
        u.setDate_creation(new Date(System.currentTimeMillis()));
        u.setEmail(email.getText());
        u.setEtat(2);
        u.setImage("");
        u.setJeton(100);
        u.setMdp(Password.hashPassword(mdp.getText()));
        u.setNom(nom.getText());
        u.setPrenom(prenom.getText());
        u.setRole(User.Role.journaliste);
        u.setType(1);
        u.setUsername(username.getText());
        u.setConfirmkey(MD5.generateKey(mdp.getText()));
        su.create(u);
        if (image != null) {
            String newName = "USER-"+u.getId()+"PROFIL-"+image.getName();
            u.setImage(image.getName());
            ImageSender is = new ImageSender("localhost", 1988, image,newName);
            ImageReceiver.get();
            u.setImage(newName);
            su.update(u);
        }else{
            u.setImage("PROFILEDEFAULT");
            su.update(u);
        }
    }

    @FXML
    private void check(KeyEvent event) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(email.getText());
        if (!this.email.getText().equals("")
                && !this.mdp.getText().equals("")
                && !this.nom.getText().equals("")
                && !this.prenom.getText().equals("")
                && !this.prenom.getText().equals("")
                && !this.rmdp.getText().equals("")
                && !this.username.getText().equals("")
                && (this.mdp.getText().equals(this.rmdp.getText()))
                && matcher.find()) {
            this.ajoter.setDisable(false);
        } else {
            this.ajoter.setDisable(true);
        }
    }

}
