/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Equipes;

import Entite.Equipe;
import Entite.Joueur;
import Presentation.Joueurs.Profile_joueurController;
import Service.ServiceEquipe;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author eloss
 */
public class Case_equipeController implements Initializable {

    @FXML
    private ImageView drapeau;
    @FXML
    private ImageView maillot;
    @FXML
    private Label nom;
    @FXML
    private Label groupe;
    @FXML
    private Label entraineur;
    @FXML
    private Label points;
    @FXML
    private Label progress;

    private Equipe equipe ;
    @FXML
    private Label qualification;
    @FXML
    private Label nb_but;
    @FXML
    private AnchorPane equipe_anchor;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void setEquipe(Equipe equipe ){
        this.equipe = equipe ;
        nom.setText(equipe.getNom());
        groupe.setText(equipe.getGroupe().getNom());
        entraineur.setText(equipe.getEntraineur().getNom());
        points.setText(Integer.toString(equipe.getPts()));
        progress.setText(equipe.getProgress().toString());
        drapeau.setImage(new Image("file:"+equipe.getDrapeau()));
        maillot.setImage(new Image("file:"+equipe.getMaillot()));
        qualification.setText(equipe.getQualification().toString());
        nb_but.setText(Integer.toString(new ServiceEquipe().nb_but_equipe(equipe)) );
    }
    public Object loadFXML(String s, Equipe E) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            loader.load();
            Profile_equipeController ac = (Profile_equipeController) loader.getController();
            ac.setEquipe(E);
            return loader.getRoot();
        } catch (IOException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @FXML
    private void afficher_profile_equipe(MouseEvent event) {
        AnchorPane ap = (AnchorPane) this.loadFXML("Profile_equipe.fxml", equipe);
        this.equipe_anchor.getChildren().clear();
        this.equipe_anchor.getChildren().add(ap);
    }
}
