/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Equipes;

import Entite.Equipe;
import Entite.Joueur;
import Entite.Match;
import Presentation.Joueurs.Case_joueur_1Controller;
import Service.ServiceEquipe;
import Service.ServiceJoueur;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author elossofa
 */
public class Profile_equipeController implements Initializable {

    @FXML
    private AnchorPane equipe_anchor;
    @FXML
    private ImageView drapeau;
    @FXML
    private ImageView maillot;
    @FXML
    private Label nom;
    @FXML
    private Label pool;
    @FXML
    private Label entraineur;
    @FXML
    private Label points;
    @FXML
    private Label nb_but;
    @FXML
    private Label qualification;
    @FXML
    private Label progress;
    @FXML
    private TableView<Joueur> liste_joueur;
    @FXML
    private TableColumn<Joueur, String> table_nom;
    @FXML
    private TableColumn<Joueur, String> table_prenom;
    @FXML
    private TableColumn<Joueur, String> table_poste;
    @FXML
    private TableColumn<Joueur, Integer> table_numero;
    @FXML
    private TableColumn<Joueur, Integer> table_age;
    @FXML
    private TableColumn<Joueur, String> table_club;
    @FXML
    private TableColumn<Joueur, Integer> table_but;
    @FXML
    private TableColumn<Joueur, Rectangle> table_image;
    
    private ObservableList<Joueur> data;
    private Equipe equipe ;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    public void remplir_table(){
        
    }
    public void setEquipe(Equipe equipe){
        this.equipe = equipe ;
        this.data = FXCollections.observableArrayList();
        nom.setText(equipe.getNom());
        entraineur.setText(equipe.getEntraineur().getNom());
        points.setText(Integer.toString(equipe.getPts()));
        progress.setText(equipe.getProgress().toString());
        drapeau.setImage(new Image("file:"+equipe.getDrapeau()));
        maillot.setImage(new Image("file:"+equipe.getMaillot()));
        qualification.setText(equipe.getQualification().toString());
        nb_but.setText(Integer.toString(new ServiceEquipe().nb_but_equipe(equipe)) );
        equipe.setListe_joueur(new ServiceEquipe().get_Joueurs(equipe));
        for(Joueur J : equipe.getListe_joueur()){
            J.setNb_but(new ServiceJoueur().nb_but_marque(J));
            data.add(J);
        }  
        table_nom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        table_prenom.setCellValueFactory(new PropertyValueFactory<>("prenom"));
        table_numero.setCellValueFactory(new PropertyValueFactory<>("numero"));
        table_age.setCellValueFactory(new PropertyValueFactory<>("age"));
        table_poste.setCellValueFactory(new PropertyValueFactory<>("poste"));
        table_club.setCellValueFactory(new PropertyValueFactory<>("club"));
        table_but.setCellValueFactory(new PropertyValueFactory<>("nb_but"));
        table_image.setCellValueFactory(new Callback<TableColumn.CellDataFeatures<Joueur, Rectangle>, ObservableValue<Rectangle>>() {
            @Override
            public ObservableValue<Rectangle> call(TableColumn.CellDataFeatures<Joueur, Rectangle> param) {
            Rectangle r = new Rectangle();
            r.setWidth(50);
            r.setHeight(50);
            r.setFill(new ImagePattern(new Image("http://localhost/Pi/image/"+param.getValue().getImage())));
                return new SimpleObjectProperty<>(r);
            }
        });
        liste_joueur.setItems(data);
    }
    public Object loadFXML(String s,Equipe E) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            loader.load();
            Case_equipeController ac = (Case_equipeController) loader.getController();
            ac.setEquipe(E);
            return loader.getRoot();
        } catch (IOException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @FXML
    private void afficher_profile_equipe(MouseEvent event) {
        AnchorPane ap = (AnchorPane) this.loadFXML("Case_equipe.fxml",equipe);
        this.equipe_anchor.getChildren().clear();
        this.equipe_anchor.getChildren().add(ap);
        this.equipe_anchor.setPrefHeight(this.equipe_anchor.getParent().getLayoutY()-475);
    }
    
}
