/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Galerie;

import Entite.Publication;
import Main.ApplicationController;
import Service.ServicePublication;
import TCPClient.ImageReceiver;
import TCPClient.ImageSender;
import Utilitaire.Session;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.Image;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class Ajouter_GalerieController implements Initializable {

    @FXML
    private ToggleGroup a;
    @FXML
    private JFXTextField titre;
    @FXML
    private JFXTextArea description;
    @FXML
    private AnchorPane var1;
    @FXML
    private HBox hbox;
    private File f;
    private String lien;
    @FXML
    private RadioButton i;
    @FXML
    private RadioButton v;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lien = "";
        this.hbox.getChildren().remove(0, this.hbox.getChildren().size());
        JFXButton upload = new JFXButton("Upload");
        this.hbox.getChildren().addAll(upload);
        upload.setOnAction((e) -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                    new FileChooser.ExtensionFilter("All Files", "*.*"));
            File selectedFile = fileChooser.showOpenDialog(var1.getScene().getWindow());
            if (selectedFile != null) {
                this.f = selectedFile;
                Rectangle r = new Rectangle(300, 200);
                Image i = new Image(this.f.toURI().toString());
                r.setFill(new ImagePattern(i));
                this.hbox.getChildren().clear();
                this.hbox.getChildren().add(upload);
                this.hbox.getChildren().add(r);
            }
        });
    }

    @FXML
    private void image(ActionEvent event) {
        lien = "";
        this.hbox.getChildren().remove(0, this.hbox.getChildren().size());
        this.f = null;
        this.hbox.getChildren().remove(0, this.hbox.getChildren().size());
        JFXButton upload = new JFXButton("Upload");
        this.hbox.getChildren().addAll(upload);
        upload.setOnAction((e) -> {
            this.hbox.getChildren().remove(0, this.hbox.getChildren().size());
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                    new FileChooser.ExtensionFilter("All Files", "*.*"));
            File selectedFile = fileChooser.showOpenDialog(var1.getScene().getWindow());
            if (selectedFile != null) {
                this.f = selectedFile;
                Rectangle r = new Rectangle(300, 200);
                Image i = new Image(this.f.toURI().toString());
                r.setFill(new ImagePattern(i));
                this.hbox.getChildren().clear();
                this.hbox.getChildren().add(upload);
                this.hbox.getChildren().add(r);
            }
        });
    }

    @FXML
    private void video(ActionEvent event) {
        lien = "";
        this.hbox.getChildren().remove(0, this.hbox.getChildren().size());
        JFXTextArea ttt = new JFXTextArea();
        this.hbox.getChildren().addAll(ttt);
        ttt.setOnKeyReleased((KeyEvent event1) -> {
            lien = ttt.getText();
        });

    }

    private void reset() {
        lien = "";
        this.description.setText("");
        this.titre.setText("");
        this.hbox.getChildren().clear();
        this.f = null;
        this.hbox.getChildren().remove(0, this.hbox.getChildren().size());
        JFXButton upload = new JFXButton("Upload");
        this.hbox.getChildren().addAll(upload);
        upload.setOnAction((e) -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Open Resource File");
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.gif"),
                    new FileChooser.ExtensionFilter("All Files", "*.*"));
            File selectedFile = fileChooser.showOpenDialog(var1.getScene().getWindow());
            if (selectedFile != null) {
                this.f = selectedFile;
                Rectangle r = new Rectangle(300, 200);
                Image i = new Image(this.f.toURI().toString());
                r.setFill(new ImagePattern(i));
                this.hbox.getChildren().clear();
                this.hbox.getChildren().add(upload);
                this.hbox.getChildren().add(r);
            }
        });
        i.setSelected(true);
        v.setSelected(false);
    }

    @FXML
    private void reset(ActionEvent event) {
        reset();
    }

    @FXML
    private void ajouter(ActionEvent event) throws IOException {
        if (!description.getText().equals("") && !titre.getText().equals("")) {
            if (f != null) {
                ServicePublication sp = new ServicePublication();
                Publication p = new Publication();
                p.setDate_creation(new Date(System.currentTimeMillis()));
                p.setDescription(description.getText());
                p.setDisliked(1);
                p.setLien("");
                p.setLiked(1);
                p.setTitre(titre.getText());
                p.setType(Publication.Type.galerie);
                p.setUser(Session.getUser());
                sp.create(p);
                String newName = "USER-" + Session.getUser().getId() + "GALERIE-" + p.getId() + "IMAGE-" + f.getName();
                ImageSender is = new ImageSender("localhost", 1988, f, newName);
                p.setLien(newName);
                sp.update(p);
                //ImageReceiver.get();
                Stage s = (Stage) this.description.getScene().getWindow();
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/Main/Application.fxml"));
                AnchorPane root = (AnchorPane) loader.load();
                ApplicationController ac = loader.getController();
                Scene scene = new Scene(root);
                s.setScene(scene);
                s.show();
            } else if (!lien.equals("")) {
                ServicePublication sp = new ServicePublication();
                Publication p = new Publication();
                p.setDate_creation(new Date(System.currentTimeMillis()));
                p.setDescription(description.getText());
                p.setDisliked(1);
                p.setLien("LIEN:" + lien);
                p.setLiked(1);
                p.setTitre(titre.getText());
                p.setType(Publication.Type.galerie);
                p.setUser(Session.getUser());
                sp.create(p);
            }

        }
        reset();
    }

}
