
package Presentation.Galerie;

import Entite.Commentaire;
import Entite.Publication;
import Entite.User;
import Presentation.Commentaire.AfficherCommentaireController;
import Service.ServiceCommentaire;
import Utilitaire.Session;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class I_GalerieController implements Initializable {
    private Publication publication;
    @FXML
    private Label titre;
    private ImageView image;
    @FXML
    private Label auteur;
    @FXML
    private JFXTextArea description;
    @FXML
    private Label date;
    @FXML
    private Label likes;
    @FXML
    private Rectangle like;
    @FXML
    private Label dislides;
    @FXML
    private Rectangle dislike;
    @FXML
    private AnchorPane cont;
    @FXML
    private StackPane stack;
    @FXML
    private VBox vbox;
    @FXML
    private JFXTextArea contenue;
    @FXML
    private JFXButton bcomment;

    public Object loadFXML(String s, Commentaire c) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        loader.load();
        AfficherCommentaireController acc = loader.getController();
        acc.setCommentaire(c);
        return loader.getRoot();
    }

    public void setPublication(Publication publication) throws FileNotFoundException, IOException {
        this.publication = publication;
        List<Commentaire> commentaires = publication.getCommentaires();
        commentaires = commentaires.stream().filter(k -> k.getEtat().equals(Commentaire.LikeDislike.none)).collect(Collectors.toList());
        for (Commentaire commentaire : commentaires) {
            AnchorPane article = (AnchorPane) loadFXML("/Presentation/Commentaire/AfficherCommentaire.fxml", commentaire);
            vbox.setPrefHeight(vbox.getPrefHeight()+article.getPrefHeight());
            vbox.getChildren().add(article);
        }
        int likes, dislikes;
        likes = dislikes = 0;
        for (Commentaire commentaire : publication.getCommentaires()) {
            if (commentaire.getEtat().equals(Commentaire.LikeDislike.dislike)) {
                dislikes++;
            }
            if (commentaire.getEtat().equals(Commentaire.LikeDislike.like)) {
                likes++;
            }
        }
        this.likes.setText(String.valueOf(likes));
        this.dislides.setText(String.valueOf(dislikes));
        this.description.setText(publication.getDescription());
        this.date.setText(publication.getDate_creation().toString());
        this.titre.setText(publication.getTitre());
        this.auteur.setText(publication.getUser().getNom());
        Image likeimage = new Image("http://localhost/PI/image/SYSTEM_LikeBlue.png");
        this.like.setFill(new ImagePattern(likeimage));
        Image dislikeimage = new Image("http://localhost/PI/image/SYSTEM_DislikeRed.png");
        this.dislike.setFill(new ImagePattern(dislikeimage));
        if (publication.getLien().startsWith("LIEN:")) {
            String embed = publication.getLien().replaceFirst("LIEN:", "");
            WebView view = new WebView();
            view.setMinSize(580, 330);
            view.setPrefSize(580, 330);
            final WebEngine eng = view.getEngine();
            eng.loadContent(embed);
            stack.getChildren().add(view);
        } else {
            try {
                Image i = new Image("http://localhost/PI/image/" + publication.getLien());
                Rectangle r = new Rectangle(500, 300);
                r.setFill(new ImagePattern(i));
                this.stack.getChildren().addAll(r);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        bcomment.setDisable(true);
    }

    @FXML
    private void comment(ActionEvent event) throws IOException {
        ServiceCommentaire sc = new ServiceCommentaire();
        Commentaire tmp = new Commentaire();
        tmp.setDate_creation(new Date(System.currentTimeMillis()));
        tmp.setDescription(contenue.getText());
        tmp.setEtat(Commentaire.LikeDislike.none);
        tmp.setUser(Session.getUser());
        sc.create(tmp, publication.getId(), Session.getUser().getId());
        AnchorPane ap = (AnchorPane) loadFXML("/Presentation/Commentaire/AfficherCommentaire.fxml", tmp);
        vbox.setPrefHeight(vbox.getPrefHeight()+ap.getPrefHeight());
        vbox.getChildren().add(0, ap);
        this.bcomment.setDisable(true);
    }

    @FXML
    private void like(MouseEvent event) {
        if (Session.getUser() != null) {
            User tmpUser = Session.getUser();
            Publication tmpPublication = this.publication;
            ServiceCommentaire sc = new ServiceCommentaire();
            List<Commentaire> l = sc.retrieveUserComment(tmpUser.getId(), tmpPublication.getId());
            l = l.stream().filter(k -> k.getDescription().equals("")).collect(Collectors.toList());
            if (l.isEmpty()) {
                Commentaire c = new Commentaire();
                c.setDate_creation(new Date(System.currentTimeMillis()));
                c.setDescription("");
                c.setEtat(Commentaire.LikeDislike.like);
                sc.create(c, tmpPublication.getId(), tmpUser.getId());
                String ll = String.valueOf(Integer.valueOf(likes.getText()) + 1);
                likes.setText(ll);
                /////
            } else {
                if (l.get(0).getEtat().equals(Commentaire.LikeDislike.dislike)) {

                    Commentaire c = l.get(0);
                    c.setEtat(Commentaire.LikeDislike.like);
                    sc.update(c);
                    String ll = String.valueOf(Integer.valueOf(likes.getText()) + 1);
                    likes.setText(ll);
                    String ld = String.valueOf(Integer.valueOf(dislides.getText()) - 1);
                    dislides.setText(ld);
                    ////
                }
            }
        }
    }

    @FXML
    private void dislike(MouseEvent event) {
        if (Session.getUser() != null) {
            User tmpUser = Session.getUser();
            Publication tmpPublication = this.publication;
            ServiceCommentaire sc = new ServiceCommentaire();
            List<Commentaire> l = sc.retrieveUserComment(tmpUser.getId(), tmpPublication.getId());
            l = l.stream().filter(k -> k.getDescription().equals("")).collect(Collectors.toList());
            if (l.isEmpty()) {
                Commentaire c = new Commentaire();
                c.setDate_creation(new Date(System.currentTimeMillis()));
                c.setDescription("");
                c.setEtat(Commentaire.LikeDislike.dislike);
                sc.create(c, tmpPublication.getId(), tmpUser.getId());
                String ld = String.valueOf(Integer.valueOf(dislides.getText()) + 1);
                dislides.setText(ld);
                ///
            } else {
                if (l.get(0).getEtat().equals(Commentaire.LikeDislike.like)) {
                    Commentaire c = l.get(0);
                    c.setEtat(Commentaire.LikeDislike.dislike);
                    sc.update(c);
                    String ld = String.valueOf(Integer.valueOf(dislides.getText()) + 1);
                    dislides.setText(ld);
                    String ll = String.valueOf(Integer.valueOf(likes.getText()) - 1);
                    likes.setText(ll);
                    //
                }
            }
        }
    }

    @FXML
    private void reset(ActionEvent event) {
        this.contenue.setText("");
    }

    @FXML
    private void check(KeyEvent event) {
        if (Session.getUser() != null) {
            ServiceCommentaire sc = new ServiceCommentaire();
            List<Commentaire> commentaires = sc.retrieveUserComment(Session.getUser().getId(), publication.getId());
            boolean flag = true;
            for (Commentaire commentaire : commentaires) {
                if (commentaire.getEtat().equals(Commentaire.LikeDislike.none)) {
                    flag = false;
                    break;
                }
            }
            if (!contenue.getText().equals("")&&flag) {
                bcomment.setDisable(false);
            } else {
                bcomment.setDisable(true);
            }
        } else {
            bcomment.setDisable(true);
        }

    }

}
