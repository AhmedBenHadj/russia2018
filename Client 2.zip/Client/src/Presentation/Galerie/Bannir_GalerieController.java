/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Galerie;

import Entite.Publication;
import Service.ServicePublication;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.shape.Rectangle;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class Bannir_GalerieController implements Initializable {

    @FXML
    private JFXButton confirmer;
    @FXML
    private AnchorPane var2;
    @FXML
    private Label var1;
    @FXML
    private Label auteur;
    @FXML
    private Label titre;
    @FXML
    private JFXTextArea description;
    @FXML
    private Label date;
    @FXML
    private Rectangle rec;
    private Publication publication;

    public Publication getPublication() {
        return publication;
    }

    public void setPublication(Publication publication) {
        this.publication = publication;
    }
    

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void confirmer(ActionEvent event) {
        ServicePublication sp =new ServicePublication();
        publication.setConfirme(Publication.Confirme.non);
        sp.update(publication);
    }
    
}
