/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Galerie;

import Entite.Commentaire;
import Presentation.Acceuil.AcceuilController;
import Entite.Publication;
import Service.ServicePublication;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class GalerieController implements Initializable {

    @FXML
    private VBox vbox;
    @FXML
    private JFXTextField recherche;
    @FXML
    private ScrollPane pane;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ServicePublication sp = new ServicePublication();
        List<Publication> galerie = sp.retrieveGalerie();
        afficher(galerie);
    }

    private void afficher(List<Publication> galerie) {
        
        galerie = galerie.stream().sorted((e, f) -> {
            List<Commentaire> ce = e.getCommentaires();
            List<Commentaire> cf = f.getCommentaires();
            ce = ce.stream().filter(k -> !k.getEtat().equals(Commentaire.LikeDislike.none)).collect(Collectors.toList());
            cf = cf.stream().filter(k -> !k.getEtat().equals(Commentaire.LikeDislike.none)).collect(Collectors.toList());
            int likec = (int) ce.stream().filter(k -> k.getEtat().equals(Commentaire.LikeDislike.like)).count();
            int dislikec = (int) ce.stream().filter(k -> k.getEtat().equals(Commentaire.LikeDislike.dislike)).count();
            int likef = (int) cf.stream().filter(k -> k.getEtat().equals(Commentaire.LikeDislike.like)).count();
            int dislikef = (int) cf.stream().filter(k -> k.getEtat().equals(Commentaire.LikeDislike.dislike)).count();
            return likef - dislikef - (likec - dislikec);
        }).collect(Collectors.toList());
        
        vbox.setPrefHeight(588 * galerie.size());
        for (int i = 0; i < galerie.size(); i++) {
            AnchorPane article = (AnchorPane) loadFXML("I_Galerie.fxml", galerie.get(i));
            vbox.getChildren().add(article);
        }
    }

    public Object loadFXML(String s) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            return loader.load();
        } catch (IOException ex) {
            Logger.getLogger(AcceuilController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Object loadFXML(String s, Publication p) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            loader.load();
            I_GalerieController ac = (I_GalerieController) loader.getController();
            ac.setPublication(p);
            return loader.getRoot();
        } catch (IOException ex) {
            Logger.getLogger(AcceuilController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @FXML
    private void rechercher(KeyEvent event) {
        String t = recherche.getText();
        ServicePublication sp = new ServicePublication();
        List<Publication> articles = sp.retrieveGalerie();
        vbox.getChildren().clear();
        if (!t.equals("")) {
            articles = articles
                    .stream()
                    .filter(s -> s.getDescription().contains(t) || s.getTitre().contains(t) || s.getUser().getNom().contains(t))
                    .collect(Collectors.toList());
        }
        afficher(articles);
    }

}
