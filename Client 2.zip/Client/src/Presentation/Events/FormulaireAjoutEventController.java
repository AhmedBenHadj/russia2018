/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Events;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import Entite.Evenement;
import Entite.Evenement.TypeCarton;
import Entite.Joueur_P;
import Entite.Match;
import Entite.Score;
import Service.ServiceEquipe;
import Service.ServiceEvenement;
import Service.ServiceJoueur;
import Service.ServiceJoueur_P;
import Service.ServiceMatch;
import Service.ServiceScore;

/**
 * FXML Controller class
 *
 * @author hseli
 */
public class FormulaireAjoutEventController implements Initializable {

   /* @FXML
    private JFXComboBox<Integer> id_match;*/
    @FXML
    private JFXComboBox<String> id_joueur;
    @FXML
    private JFXComboBox<Enum> id_carton;
    @FXML
    private JFXComboBox<Integer> id_but;
    @FXML
    private JFXTextField id_temps;
    @FXML
    private JFXButton id_ajouter;
    @FXML
    private JFXComboBox<String> id_equipe_1;
    @FXML
    private JFXComboBox<String> id_equipe_2;
    @FXML
    private JFXComboBox<String> id_equipe;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        fillCombo();
        id_ajouter.setOnAction(this::ajouter);
        id_equipe_1.setOnAction(this::afficher_E2);
        id_equipe.setOnAction(this::afficher_JP);
    }    
    public void fillCombo(){
       // ObservableList<Integer> data = FXCollections.observableArrayList();
        ObservableList<String> data4 = FXCollections.observableArrayList();
        //ObservableList<String> data5 = FXCollections.observableArrayList();
          ServiceMatch S = new ServiceMatch();
        List<Match> LM=S.get_Match();
        for(Match J : LM){
           // data.add(J.getId());
            data4.add(J.getE1().getNom());
            //data5.add(J.getE2().getNom());
            
        }
        id_equipe_1.setItems(data4);
        //id_equipe_2.setItems(data5);
        /*id_match.setItems(null);
        id_match.setItems(data);*/
        ObservableList<String> data1 = FXCollections.observableArrayList();
        ServiceJoueur_P SJ=new ServiceJoueur_P();
        List<Joueur_P> LJ=SJ.getALL();
        for (Joueur_P joueur_P : LJ) {
            
             data1.add(joueur_P.getJ().getNom());
        }
        id_joueur.setItems(data1);
        ObservableList<Enum> data2 = FXCollections.observableArrayList();
        data2.add(Evenement.TypeCarton.PasC);
        data2.add(Evenement.TypeCarton.Jaune);
        data2.add(Evenement.TypeCarton.Rouge);
        id_carton.setItems(data2);
        ObservableList<Integer> data3 = FXCollections.observableArrayList();
        data3.add(0);
        data3.add(1);
        id_but.setItems(data3);
        
        
        
    }
    public void afficher_JP(ActionEvent event){
        ObservableList<String> data_JP = FXCollections.observableArrayList();
        ServiceJoueur_P SJP=new ServiceJoueur_P();
        List<String> LS=SJP.recuperer_Par_NomEq(this.id_equipe.getValue());
        for (String string : LS) {
            data_JP.add(string);
        }
        id_joueur.setItems(data_JP);
    }
    public void afficher_E2(ActionEvent event){
          ObservableList<String> data_Eq2 = FXCollections.observableArrayList();
          ObservableList<String> data_Eq = FXCollections.observableArrayList();
          ServiceMatch SM=new ServiceMatch();
          ServiceEquipe SE=new ServiceEquipe();
          List<Integer> LI=SM.recuperer_IdE2_par_IDE1(SE.recuperer_Id_par_nom(this.id_equipe_1.getValue()));
          for (Integer integer : LI) {
            data_Eq2.add(SE.recuperer_Nom_par_ID(integer));
            data_Eq.add(SE.recuperer_Nom_par_ID(integer));
        }
          
          id_equipe_2.setItems(data_Eq2);
          data_Eq.add(this.id_equipe_1.getValue());
          
          id_equipe.setItems(data_Eq);
    }
     private void ajouter(ActionEvent event) {
        ServiceJoueur_P SJ=new ServiceJoueur_P();
        ServiceMatch SM=new ServiceMatch();
        ServiceEquipe SEq=new ServiceEquipe();
        ServiceEvenement SE=new ServiceEvenement();
         Evenement M = new Evenement();
         int i1=SEq.recuperer_Id_par_nom(this.id_equipe_1.getValue());
        int i2=SEq.recuperer_Id_par_nom(this.id_equipe_2.getValue());
        // M.setM(SM.get(id_match.getValue()));
        M.setM(SM.get1(i1, i2));
         M.setJoueur(SJ.get(SJ.recuperer_Id_par_nom((String)id_joueur.getValue())));
         M.setCarton((TypeCarton)id_carton.getValue());
         M.setBut(id_but.getValue());
         //if(Integer.parseInt(id_temps.getText())<90 && Integer.parseInt(id_temps.getText())>0 ){
             M.setTemps(Integer.parseInt(id_temps.getText()));
         
        
         
         
         if(id_but.getValue()==0)
         {            
            SE.ajouter_Evenement(M);
         }
         else
         {
             SE.ajouter_Evenement1(M);
             update_score();
         }
        // }
        /* else{
             System.out.println("3asba");
         }*/
           
        
    }
     public void update_score(){
        
        ServiceEquipe SEq=new ServiceEquipe();
        ServiceMatch SM=new ServiceMatch();
        int i1=SEq.recuperer_Id_par_nom(this.id_equipe_1.getValue());
        int i2=SEq.recuperer_Id_par_nom(this.id_equipe_2.getValue());
        int id_match =SM.get2(i1, i2);
         System.out.println(id_match);
        ServiceEvenement se = new ServiceEvenement();
        ServiceScore SS=new ServiceScore();
        Evenement evenement = se.get_Event1_Par_ID(id_match);
            int b = evenement.getBut();
            if (b != 0){
                String e1 = evenement.getM().getE1().getNom();
                String e2 = evenement.getM().getE2().getNom();

                String em = evenement.getJoueur().getJ().getEquipe().getNom();
                Score S=SS.get(id_match);
                
                if (em.equals(e1)) {
                    
                   // S.setId(id_match);
                    int A=0;
                    A=S.getA();
                    A++;
                    S.setA(A);
                    SS.modifier_A(S);
                     
                } else if(em.equals(e2)) {
                    
                    //S.setId(id_match);
                    int B=0;
                    B=S.getB();
                    B++;
                    S.setB(B);
                    SS.modifier_B(S);
                }

            }

        
     }
    
}
