/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Stades;

import Entite.Stade;
import Service.ServiceStade;
import com.lynden.gmapsfx.GoogleMapView;
import com.lynden.gmapsfx.MapComponentInitializedListener;
import com.lynden.gmapsfx.javascript.object.GoogleMap;
import com.lynden.gmapsfx.javascript.object.InfoWindow;
import com.lynden.gmapsfx.javascript.object.InfoWindowOptions;
import com.lynden.gmapsfx.javascript.object.LatLong;
import com.lynden.gmapsfx.javascript.object.MapOptions;
import com.lynden.gmapsfx.javascript.object.MapTypeIdEnum;
import com.lynden.gmapsfx.javascript.object.Marker;
import com.lynden.gmapsfx.javascript.object.MarkerOptions;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author hseli
 */
public class GoogleMapsController implements Initializable, MapComponentInitializedListener {

    @FXML
    private GoogleMapView mapView;

    private GoogleMap map;
    private GoogleMap map1;
    private GoogleMap map2;
    private Stade stade ;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        mapView.addMapInializedListener(this);

    }

    @Override
    public void mapInitialized() {

        ServiceStade SS = new ServiceStade();

        if(this.stade.getId() == 1){
            LatLong fredWilkieLocation = new LatLong(54.6982, 20.5339);

                //Set the initial properties of the map.
                MapOptions mapOptions = new MapOptions();

                mapOptions.center(new LatLong(54.6982, 20.5339))
                        .mapType(MapTypeIdEnum.ROADMAP.ROADMAP)
                        .overviewMapControl(false)
                        .panControl(false)
                        .rotateControl(false)
                        .scaleControl(false)
                        .streetViewControl(false)
                        .zoomControl(false)
                        .zoom(12);

                map = mapView.createMap(mapOptions);
                MarkerOptions markerOptions5 = new MarkerOptions();
                markerOptions5.position(fredWilkieLocation);
                Marker fredWilkieMarker = new Marker(markerOptions5);
                map.addMarker(fredWilkieMarker);
                
                InfoWindowOptions infoWindowOptions = new InfoWindowOptions();
                infoWindowOptions.content("<h2>Arena Baltika</h2>"
                        + "Current Location: Solnechnyy Bul'var, Konigsberg,<br> Kaliningradskaya oblast',<br>Russia, 236006<br>"
                        + "Latitude : 54.6982° N "+"<br> Longitude : 20.5339° E");
                

                InfoWindow fredWilkeInfoWindow = new InfoWindow(infoWindowOptions);
                fredWilkeInfoWindow.open(map, fredWilkieMarker);
        }
        else if(this.stade.getId() == 2){
            LatLong fredWilkieLocation = new LatLong(48.7345, 44.5483);

                //Set the initial properties of the map.
                MapOptions mapOptions = new MapOptions();

                mapOptions.center(new LatLong(48.7345, 44.5483))
                        .mapType(MapTypeIdEnum.ROADMAP.ROADMAP)
                        .overviewMapControl(false)
                        .panControl(false)
                        .rotateControl(false)
                        .scaleControl(false)
                        .streetViewControl(false)
                        .zoomControl(false)
                        .zoom(12);

                map1 = mapView.createMap(mapOptions);

              
                MarkerOptions markerOptions5 = new MarkerOptions();
                markerOptions5.position(fredWilkieLocation);

                Marker fredWilkieMarker = new Marker(markerOptions5);

                map1.addMarker(fredWilkieMarker);

                InfoWindowOptions infoWindowOptions = new InfoWindowOptions();
                infoWindowOptions.content("<h2>Centralniy</h2>"
                        + "Current Location: Volgogradskaya oblast'\n" +
                        "Russie\n" +
                        "400005<br>"
                        + "Latitude : 48.7345° N<br>"+"Longitude : 44.5483° E");

                InfoWindow fredWilkeInfoWindow = new InfoWindow(infoWindowOptions);
                fredWilkeInfoWindow.open(map1, fredWilkieMarker);
        }
        else if(this.stade.getId() == 3){
            LatLong fredWilkieLocation = new LatLong(53.2781, 50.2389);

                //Set the initial properties of the map.
                MapOptions mapOptions = new MapOptions();

                mapOptions.center(new LatLong(53.2781, 50.2389))
                        .mapType(MapTypeIdEnum.ROADMAP.ROADMAP)
                        .overviewMapControl(false)
                        .panControl(false)
                        .rotateControl(false)
                        .scaleControl(false)
                        .streetViewControl(false)
                        .zoomControl(false)
                        .zoom(12);

                map1 = mapView.createMap(mapOptions);

              
                MarkerOptions markerOptions5 = new MarkerOptions();
                markerOptions5.position(fredWilkieLocation);

                Marker fredWilkieMarker = new Marker(markerOptions5);

                map1.addMarker(fredWilkieMarker);

                InfoWindowOptions infoWindowOptions = new InfoWindowOptions();
                infoWindowOptions.content("<h2>Cosmos Arena</h2>"
                        + "Current Location: Samara, Samara Oblast'\n" +
                        "Russia\n" +
                        "443072<br>"
                        + "Latitude : 53.2781° N<br>"+"Longitude : 50.2389° E");

                InfoWindow fredWilkeInfoWindow = new InfoWindow(infoWindowOptions);
                fredWilkeInfoWindow.open(map1, fredWilkieMarker);
        }
        else if(this.stade.getId() == 4){
            LatLong fredWilkieLocation = new LatLong(55.8210, 49.1610);

                //Set the initial properties of the map.
                MapOptions mapOptions = new MapOptions();

                mapOptions.center(new LatLong(55.8210, 49.1610))
                        .mapType(MapTypeIdEnum.ROADMAP.ROADMAP)
                        .overviewMapControl(false)
                        .panControl(false)
                        .rotateControl(false)
                        .scaleControl(false)
                        .streetViewControl(false)
                        .zoomControl(false)
                        .zoom(12);

                map1 = mapView.createMap(mapOptions);

              
                MarkerOptions markerOptions5 = new MarkerOptions();
                markerOptions5.position(fredWilkieLocation);

                Marker fredWilkieMarker = new Marker(markerOptions5);

                map1.addMarker(fredWilkieMarker);

                InfoWindowOptions infoWindowOptions = new InfoWindowOptions();
                infoWindowOptions.content("<h2>Kazan Arena</h2>"
                        + "Current Location: пр-кт Ямашева, 115 А, Kazan, Respublika Tatarstan'\n" +
                        "Russia\n" +
                        "421001<br>"
                        + "Latitude : 55.8210° N<br>"+"Longitude : 49.1610° E");

                InfoWindow fredWilkeInfoWindow = new InfoWindow(infoWindowOptions);
                fredWilkeInfoWindow.open(map1, fredWilkieMarker);
        }
         else if(this.stade.getId() == 5){
            LatLong fredWilkieLocation = new LatLong(59.9730, 30.2202);

                //Set the initial properties of the map.
                MapOptions mapOptions = new MapOptions();

                mapOptions.center(new LatLong(59.9730, 30.2202))
                        .mapType(MapTypeIdEnum.ROADMAP.ROADMAP)
                        .overviewMapControl(false)
                        .panControl(false)
                        .rotateControl(false)
                        .scaleControl(false)
                        .streetViewControl(false)
                        .zoomControl(false)
                        .zoom(12);

                map1 = mapView.createMap(mapOptions);

              
                MarkerOptions markerOptions5 = new MarkerOptions();
                markerOptions5.position(fredWilkieLocation);

                Marker fredWilkieMarker = new Marker(markerOptions5);

                map1.addMarker(fredWilkieMarker);

                InfoWindowOptions infoWindowOptions = new InfoWindowOptions();
                infoWindowOptions.content("<h2>Krestovsky Stadium</h2>"
                        + "Current Location: Futbol'naya Alleya, 1, Sankt-Peterburg'\n" +
                        "Russia\n" +
                        "197110<br>"
                        + "Latitude : 59.9730° N<br>"+"Longitude : 30.2202° E");

                InfoWindow fredWilkeInfoWindow = new InfoWindow(infoWindowOptions);
                fredWilkeInfoWindow.open(map1, fredWilkieMarker);
        }
        else if(this.stade.getId() == 6){
            LatLong fredWilkieLocation = new LatLong(47.2096, 39.7384);

                //Set the initial properties of the map.
                MapOptions mapOptions = new MapOptions();

                mapOptions.center(new LatLong(47.2096, 39.7384))
                        .mapType(MapTypeIdEnum.ROADMAP.ROADMAP)
                        .overviewMapControl(false)
                        .panControl(false)
                        .rotateControl(false)
                        .scaleControl(false)
                        .streetViewControl(false)
                        .zoomControl(false)
                        .zoom(12);

                map1 = mapView.createMap(mapOptions);

              
                MarkerOptions markerOptions5 = new MarkerOptions();
                markerOptions5.position(fredWilkieLocation);

                Marker fredWilkieMarker = new Marker(markerOptions5);

                map1.addMarker(fredWilkieMarker);

                InfoWindowOptions infoWindowOptions = new InfoWindowOptions();
                infoWindowOptions.content("<h2>Levberdon Arena</h2>"
                        + "Current Location: Rostov-on-Don, Rostov Oblast'\n" +
                        "Russia\n" +
                        "344002<br>"
                        + "Latitude : 47.2096° N<br>"+"Longitude : 39.7384° E");

                InfoWindow fredWilkeInfoWindow = new InfoWindow(infoWindowOptions);
                fredWilkeInfoWindow.open(map1, fredWilkieMarker);
        }
        else if(this.stade.getId() == 7){
            LatLong fredWilkieLocation = new LatLong(55.7158, 37.5537);

                //Set the initial properties of the map.
                MapOptions mapOptions = new MapOptions();

                mapOptions.center(new LatLong(55.7158, 37.5537))
                        .mapType(MapTypeIdEnum.ROADMAP.ROADMAP)
                        .overviewMapControl(false)
                        .panControl(false)
                        .rotateControl(false)
                        .scaleControl(false)
                        .streetViewControl(false)
                        .zoomControl(false)
                        .zoom(12);

                map1 = mapView.createMap(mapOptions);

              
                MarkerOptions markerOptions5 = new MarkerOptions();
                markerOptions5.position(fredWilkieLocation);

                Marker fredWilkieMarker = new Marker(markerOptions5);

                map1.addMarker(fredWilkieMarker);

                InfoWindowOptions infoWindowOptions = new InfoWindowOptions();
                infoWindowOptions.content("<h2>Luzhniki</h2>"
                        + "Current Location: ул. Лужники, 24, Москва, г. Москва'\n" +
                        "Russia\n" +
                        "119048<br>"
                        + "Latitude : 55.7158° N<br>"+"Longitude : 37.5537° E");

                InfoWindow fredWilkeInfoWindow = new InfoWindow(infoWindowOptions);
                fredWilkeInfoWindow.open(map1, fredWilkieMarker);
        }
        else if(this.stade.getId() == 8){
            LatLong fredWilkieLocation = new LatLong(54.1818, 45.2039);

                //Set the initial properties of the map.
                MapOptions mapOptions = new MapOptions();

                mapOptions.center(new LatLong(54.1818, 45.2039))
                        .mapType(MapTypeIdEnum.ROADMAP.ROADMAP)
                        .overviewMapControl(false)
                        .panControl(false)
                        .rotateControl(false)
                        .scaleControl(false)
                        .streetViewControl(false)
                        .zoomControl(false)
                        .zoom(12);

                map1 = mapView.createMap(mapOptions);

              
                MarkerOptions markerOptions5 = new MarkerOptions();
                markerOptions5.position(fredWilkieLocation);

                Marker fredWilkieMarker = new Marker(markerOptions5);

                map1.addMarker(fredWilkieMarker);

                InfoWindowOptions infoWindowOptions = new InfoWindowOptions();
                infoWindowOptions.content("<h2>Mordovia Arena</h2>"
                        + "Current Location: Volgogradskaya Ulitsa, 11, Saransk, Respublika Mordoviya'\n" +
                        "Russia\n" +
                        "430009<br>"
                        + "Latitude : 54.1818° N<br>"+"Longitude : 45.2039° E");

                InfoWindow fredWilkeInfoWindow = new InfoWindow(infoWindowOptions);
                fredWilkeInfoWindow.open(map1, fredWilkieMarker);
        }
        
    }
    public void SetStade(Stade stade){
        this.stade = stade ;
    }

}
