/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Stades;

import Entite.Stade;
import Service.ServiceStade;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.util.Callback;

/**
 * FXML Controller class
 *
 * @author hseli
 */
public class Tout_les_stadesController implements Initializable {

    @FXML
    private TableView<Stade> id_stades;
    @FXML
    private TableColumn<Stade, String> id_nom;
    @FXML
    private TableColumn<Stade, String> id_ville;
    @FXML
    private TableColumn<Stade, Integer> id_capacite;

    private ObservableList<Stade> data;
    private Button button = new Button("Geolocaliser");

    private TableColumn<Stade, Button> id_button;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        fillTable();
    }

    private void fillTable() {
        data = FXCollections.observableArrayList();
        // TableColumn geo=new TableColumn("Location");
        ServiceStade SS = new ServiceStade();

        List<Stade> LM = SS.get_Stade();
        for (Stade stade : LM) {
            data.add(new Stade(stade.getId(), stade.getNom(), stade.getAdresse(), stade.getCapacite()));
        }

        id_nom.setCellValueFactory(new PropertyValueFactory<>("nom"));
        id_ville.setCellValueFactory(new PropertyValueFactory<>("adresse"));
        id_capacite.setCellValueFactory(new PropertyValueFactory<>("capacite"));
        /*id_stades.getColumns().add(geo);
        geo.setCellValueFactory(new PropertyValueFactory<>("button"));*/
        TableColumn col_action = new TableColumn<>("Location");
        col_action.setSortable(false);

        col_action.setCellValueFactory(
                new Callback<TableColumn.CellDataFeatures<Stade, Boolean>, ObservableValue<Boolean>>() {

            @Override
            public ObservableValue<Boolean> call(TableColumn.CellDataFeatures<Stade, Boolean> p) {
                return new SimpleBooleanProperty(p.getValue() != null);
            }
        });

        col_action.setCellFactory(
                new Callback<TableColumn<Stade, Boolean>, TableCell<Stade, Boolean>>() {

            @Override
            public TableCell<Stade, Boolean> call(TableColumn<Stade, Boolean> p) {
                return new ButtonCell();
            }

        });
        id_stades.getColumns().add(col_action);
        id_stades.setItems(null);
        id_stades.setItems(data);
    }

    private static class ButtonCell extends TableCell<Stade, Boolean> {

        Button cellButton = new Button("Geolocaliser");

        //Button cellButton1 = new Button("Geolocaliser");
        public Object loadFXML(String s, Stade stade) {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource(s));
            try {
                loader.load();
                GoogleMapsController ac = (GoogleMapsController) loader.getController();
                ac.SetStade(stade);
                return loader.getRoot();
            } catch (IOException ex) {
                Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
            }
            return null;
        }

        ButtonCell() {

            cellButton.setOnAction(new EventHandler<ActionEvent>() {

                @Override
                public void handle(ActionEvent t) {
                    // do something when button clicked
                    //...
                    Stade currentPerson = (Stade) ButtonCell.this.getTableView().getItems().get(ButtonCell.this.getIndex());
                    int i1 = currentPerson.getId();
                    Stade stade = new ServiceStade().get(i1);
                    Parent root1 = (Parent) new ButtonCell().loadFXML("/Presentation/Stades/GoogleMaps.fxml", stade);
                    Stage stage = new Stage();
                    stage.setScene(new Scene(root1));
                    stage.show();

                    /*if(i1==1)
                    {
                    try {
                        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Presentation/view/GoogleMaps.fxml"));
                        Parent root1;
                        root1 = (Parent) fxmlLoader.load();
                        Stage stage = new Stage();
                        stage.setScene(new Scene(root1));  
                        stage.show();
                    } catch (IOException ex) {
                        Logger.getLogger(Tout_les_stadesController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    }
                    if(i1==2)
                    {
                    try {
                        FXMLLoader fxmlLoader1 = new FXMLLoader(getClass().getResource("/Presentation/view/GoogleMaps.fxml"));
                        Parent root2;
                        root2 = (Parent) fxmlLoader1.load();
                        Stage stage = new Stage();
                        stage.setScene(new Scene(root2));  
                        stage.show();
                    } catch (IOException ex) {
                        Logger.getLogger(Tout_les_stadesController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    }
                    if(i1==3)
                    {
                    try {
                        FXMLLoader fxmlLoader1 = new FXMLLoader(getClass().getResource("/Presentation/view/GoogleMaps.fxml"));
                        Parent root2;
                        root2 = (Parent) fxmlLoader1.load();
                        Stage stage = new Stage();
                        stage.setScene(new Scene(root2));  
                        stage.show();
                    } catch (IOException ex) {
                        Logger.getLogger(Tout_les_stadesController.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    }*/
                }
            });
        }

        //Display button if the row is not empty
        @Override
        protected void updateItem(Boolean t, boolean empty) {
            super.updateItem(t, empty);
            if (!empty) {
                setGraphic(cellButton);
            }
        }

    }

}
