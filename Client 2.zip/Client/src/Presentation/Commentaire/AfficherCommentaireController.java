/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Commentaire;

import Entite.Commentaire;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class AfficherCommentaireController implements Initializable {

    @FXML
    private Label date;
    @FXML
    private Label commentaireAuteur;
    @FXML
    private Label commentaireDesc;
    
    private Commentaire commentaire;

    public Commentaire getCommentaire() {
        return commentaire;
    }

    public void setCommentaire(Commentaire commentaire) {
        this.date.setText(commentaire.getDate_creation().toString());
        this.commentaireDesc.setText(commentaire.getDescription());
        System.out.println(commentaire.getUser().getUsername()+"-----");
        this.commentaireAuteur.setText(commentaire.getUser().getUsername());
    }
    

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
