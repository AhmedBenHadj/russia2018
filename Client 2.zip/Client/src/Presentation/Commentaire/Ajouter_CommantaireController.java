/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Commentaire;

import Entite.Commentaire;
import Entite.Publication;
import Entite.User;
import Service.ServiceCommentaire;
import Utilitaire.Session;
import com.jfoenix.controls.JFXTextArea;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class Ajouter_CommantaireController implements Initializable {

    @FXML
    private JFXTextArea contenue;
    private Publication publication;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.publication = new Publication();
        this.publication.setId(16);
    }    

    @FXML
    private void annuler(ActionEvent event) {
        this.contenue.setText("");
        
        
    }


    public Publication getPublication() {
        return publication;
    }

    public void setPublication(Publication publication) {
        this.publication = publication;
    }

    @FXML
    private void ajouter(ActionEvent event) {
        if(!this.contenue.getText().equals("")){
            ServiceCommentaire sc = new ServiceCommentaire();
            Commentaire c = new Commentaire();
            c.setDate_creation(new Date(System.currentTimeMillis()));
            c.setDescription(this.contenue.getText());
            sc.create(c,publication.getId(),Session.getUser().getId());
            System.out.println(c);
        }
    }
    
}
