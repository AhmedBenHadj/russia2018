/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Joueurs;

import Entite.Abonnement;
import Entite.Joueur;
import Service.ServiceAbonnement;
import Utilitaire.Session;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author eloss
 */
public class Case_joueur_1Controller implements Initializable {

    @FXML
    private Label nom;
    @FXML
    private Label prenom;
    @FXML
    private Label age;
    @FXML
    private Label club;
    @FXML
    private Label equipe;
    @FXML
    private Label poste;
    private Joueur joueur;
    @FXML
    private ImageView image;
    @FXML
    private JFXButton abonner;
    @FXML
    private AnchorPane anchor_case_joueur;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    public void setJoueur(Joueur J) {
        this.joueur = J;
        nom.setText(J.getNom());
        prenom.setText(J.getPrenom());
        poste.setText(J.getPoste());
        age.setText(Integer.toString(J.getAge()));
        club.setText(J.getClub());
        equipe.setText(J.getEquipe().getNom());
        //image.setImage(new Image("/image/"+J.getImage()));
        if (Session.getUser() != null) {
            abonner.setVisible(true);
            if (new ServiceAbonnement().get_users_etleur_Joueur().get(Session.getUser()) != null) {
                if (new ServiceAbonnement().get_users_etleur_Joueur().get(Session.getUser()).contains(this.joueur)) {
                    abonner.setText("Abonnée");
                } else {
                    abonner.setText("s'abonner");
                }
            }
        }
    }

    @FXML
    private void s_abonner(ActionEvent event) {

        Abonnement A = new Abonnement(Session.getUser(), joueur);
        if (abonner.getText().equals("s'abonner")) {
            new ServiceAbonnement().s_abonner_a(Session.getUser(), joueur);
            abonner.setText("Abonnée");
        } else {
            new ServiceAbonnement().supprimer(new ServiceAbonnement().get(Session.getUser(), joueur));
            abonner.setText("s'abonner");
        }
    }

    public Object loadFXML(String s, Joueur j) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            loader.load();
            Profile_joueurController ac = (Profile_joueurController) loader.getController();
            ac.SetJoueur(j);
            return loader.getRoot();
        } catch (IOException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @FXML
    private void afficher_profil_joueur(MouseEvent event) {
        AnchorPane ap = (AnchorPane) this.loadFXML("Profile_joueur.fxml", joueur);
        this.anchor_case_joueur.getChildren().clear();
        this.anchor_case_joueur.getChildren().add(ap);
    }

}
