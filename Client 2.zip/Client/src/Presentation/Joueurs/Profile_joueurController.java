/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Joueurs;

import Entite.Abonnement;
import Entite.Joueur;
import Service.ServiceAbonnement;
import Service.ServiceUser;
import Utilitaire.Session;
import Utilitaire.Statistique;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

/**
 * FXML Controller class
 *
 * @author eloss
 */
public class Profile_joueurController implements Initializable {

    @FXML
    private ImageView image;
    @FXML
    private Label nom;
    @FXML
    private Label prenom;
    @FXML
    private Label age;
    @FXML
    private Label numero;
    @FXML
    private Label club;
    @FXML
    private Label poste;
    @FXML
    private Label nom_equipe;
    @FXML
    private ImageView image_equipe;

    private Joueur joueur ;
    @FXML
    private JFXButton abonner;
    @FXML
    private AnchorPane anchor_case_joueur;
    @FXML
    private AnchorPane emplacement_profile;
    private Statistique stat = new Statistique() ;
    @FXML
    private HBox h_box;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        if(Session.getUser() != null){
            abonner.setVisible(true);
            if(new ServiceAbonnement().get_users_etleur_Joueur().get(new ServiceUser().retrieveId(Session.getUser().getId())) != null){
                if(new ServiceAbonnement().get_users_etleur_Joueur().get(new ServiceUser().retrieveId(Session.getUser().getId())).contains(this.joueur)){
                    abonner.setText("Abonnée");
                }
                else
                    abonner.setText("s'abonner");
            }
        }
    }    

    @FXML
    private void afficher_profil_equipe(MouseEvent event) {
    }
    
    public void SetJoueur(Joueur joueur){
        this.joueur = joueur ;
        nom_equipe.setText(joueur.getEquipe().getNom());
        poste.setText(joueur.getPoste().toString());
        club.setText(joueur.getClub());
        numero.setText(Integer.toString(joueur.getNumero()));
        age.setText(Integer.toString(joueur.getAge()));
        nom.setText(joueur.getNom());
        prenom.setText(joueur.getPrenom());
        //image.setImage(new Image("/image/"+joueur.getImage()));
        //image_equipe.setImage(new Image("file:"+joueur.getEquipe().getDrapeau()));
        this.set_h_box();
    }
    private void set_h_box(){
        this.stat.setjoueur(joueur);
        this.h_box.setPrefWidth(stat.getAll().size() * 600);
        for(PieChart chart :stat.getAll()){
            this.h_box.getChildren().add(chart);
        }
    }
    public Object loadFXML(String s,Joueur j) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            loader.load();
            Case_joueur_1Controller ac = (Case_joueur_1Controller) loader.getController();
            ac.setJoueur(j);
            return loader.getRoot();
        } catch (IOException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    @FXML
    private void non_afficher_profil(MouseEvent event) {
        AnchorPane ap = (AnchorPane) this.loadFXML("Case_joueur_1.fxml", joueur);
        this.anchor_case_joueur.getChildren().clear();
        this.anchor_case_joueur.getChildren().add(ap);
        this.anchor_case_joueur.setPrefHeight(this.anchor_case_joueur.getParent().getLayoutY()-475);
    }

    @FXML
    private void abonner(ActionEvent event) {
        boolean aux=false ;
        Abonnement A = new Abonnement(Session.getUser(), joueur);
        if(abonner.getText().equals("s'abonner")){
            new ServiceAbonnement().s_abonner_a(Session.getUser(), joueur);
            abonner.setText("Abonnée");
        }
        else{
            new ServiceAbonnement().supprimer(new ServiceAbonnement().get(Session.getUser(), joueur));
            abonner.setText("s'abonner");
        }
    }
}
