/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Acceuil;

import Entite.Publication;
import Service.ServicePublication;
import Utilitaire.Session;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class Ajouter_ArticleController implements Initializable {

    @FXML
    private JFXTextField titre;
    @FXML
    private JFXTextArea description;

    @FXML
    private AnchorPane ghassen;
    @FXML
    private JFXButton ajouter;

    
    

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    @FXML
    private void reset() {
        this.titre.setText("");
        this.description.setText("");
    }

    private void reset(ActionEvent event) {
        reset();
    }

    @FXML
    private void ajouter(ActionEvent event) throws IOException {
        if (!"".equals(this.description.getText()) && !"".equals(this.titre.getText())) {
            ServicePublication sp = new ServicePublication();
            Publication p = new Publication();
            p.setType(Publication.Type.article);
            p.setDescription(this.description.getText());
            p.setTitre(this.titre.getText());
            p.setLien("");
            p.setUser(Session.getUser());
            p.setDate_creation(new Date(System.currentTimeMillis()));
            p.setLiked(0);
            p.setDisliked(0);
            sp.create(p);
            reset();
            
        }
    }

    public Object loadFXML(String s) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            loader.load();
            ArticleController ac = (ArticleController) loader.getController();
            return loader.getRoot();
        } catch (IOException ex) {
            Logger.getLogger(AcceuilController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

}
