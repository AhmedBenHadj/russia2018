/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Acceuil;

import Entite.Publication;
import Service.ServicePublication;
import Utilitaire.Session;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class Mes_ArticlesController implements Initializable {

    @FXML
    private ScrollPane scroll;
    @FXML
    private VBox vbox;
    @FXML
    private JFXTextField recherche;

    

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ServicePublication sp = new ServicePublication();
        List<Publication> ma = sp.retrieveIdUser(Session.getUser().getId());
        ma.forEach((publication) -> {
            publication.setUser(Session.getUser());
        });
        afficher(ma);
        
    }

    private void afficher(List<Publication> articles) {
        articles = articles.stream()
                .filter((e)->e.getType().toString().equals(Publication.Type.article.toString()))
                .collect(Collectors.toList());
        vbox.setPrefHeight(200 * articles.size());
        for (int i = 0; i < articles.size(); i++) {
            AnchorPane article = (AnchorPane) loadFXML("Article.fxml", articles.get(i));
            vbox.getChildren().add(article);
        }
    }

    public Object loadFXML(String s) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            return loader.load();
        } catch (IOException ex) {
            Logger.getLogger(AcceuilController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public Object loadFXML(String s, Publication p) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            loader.load();
            ArticleController ac = (ArticleController) loader.getController();
            ac.setPublication(p);
            return loader.getRoot();
        } catch (IOException ex) {
            Logger.getLogger(AcceuilController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @FXML
    private void recherche(KeyEvent event) {
        String t = recherche.getText();
        ServicePublication sp = new ServicePublication();
        List<Publication> articles = sp.retrieveIdUser(5);
        vbox.getChildren().clear();
        if (!t.equals("")) {
            articles = articles
                    .stream()
                    .filter(s -> s.getDescription().contains(t)||s.getTitre().contains(t))
                    .collect(Collectors.toList());
        }
        afficher(articles);
    }

    @FXML
    private void recherche(ActionEvent event) {
    }
    
}
