/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Acceuil;

import Entite.Publication;
import com.jfoenix.controls.JFXTextArea;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class ArticleController implements Initializable {

    private Publication publication;
    @FXML
    private AnchorPane a1;
    @FXML
    private Label titre;

    @FXML
    private JFXTextArea description;

    @FXML
    private Label auteur;
    @FXML
    private Label date;
        

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }

    public void setPublication(Publication publication) {
        this.publication = publication;
        this.titre.setText(this.publication.getTitre());
        this.auteur.setText(this.publication.getUser().getNom());
        this.description.setText(this.publication.getDescription());
        this.date.setText(this.publication.getDate_creation().toString());
    }

}
