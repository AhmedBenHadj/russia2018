/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Acceuil;

import Entite.Publication;
import Service.ServicePublication;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class AcceuilController implements Initializable {

    @FXML
    private VBox vbox;

    @FXML
    private ScrollPane scrollpane;
    @FXML
    private JFXTextField recherche;


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        ServicePublication sp = new ServicePublication();
        List<Publication> articles = sp.retrieveArticle();
        afficher(articles);
        
    }

    private void afficher(List<Publication> articles) {
        vbox.setPrefHeight((200 * articles.size())+300);
        for (int i = 0; i < articles.size(); i++) {
            AnchorPane article = (AnchorPane) loadFXML("Article.fxml", articles.get(i));
            vbox.getChildren().add(article);
        }
    }

    public Object loadFXML(String s, Publication p) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            loader.load();
            ArticleController ac = (ArticleController) loader.getController();
            ac.setPublication(p);
            return loader.getRoot();
        } catch (IOException ex) {
            Logger.getLogger(AcceuilController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @FXML
    private void rechercher(KeyEvent event) {
        String t = recherche.getText();
        ServicePublication sp = new ServicePublication();
        List<Publication> articles = sp.retrieveArticle();
        vbox.getChildren().clear();
        if (!t.equals("")) {
            articles = articles
                    .stream()
                    .filter(s -> s.getDescription().contains(t) || s.getTitre().contains(t) || s.getUser().getNom().contains(t))
                    .collect(Collectors.toList());
        }
        afficher(articles);
    }
}
