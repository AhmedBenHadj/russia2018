/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Acceuil;

import Entite.Publication;
import Main.DashboardController;
import Service.ServicePublication;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class ArticleMSController implements Initializable {

    @FXML
    private JFXTextField titre;
    @FXML
    private JFXTextArea description;
    @FXML
    private Label date;
    private Publication publication;


    public Publication getPublication() {
        return publication;
    }

    public void setPublication(Publication publication) {
        this.publication = publication;
        this.titre.setText(publication.getTitre());
        this.description.setText(publication.getDescription());
        this.date.setText(publication.getDate_creation().toString());
    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void reset(ActionEvent event) {
        this.titre.setText(publication.getTitre());
        this.description.setText(publication.getDescription());
    }

    @FXML
    private void Supprimer(ActionEvent event) throws IOException {
        ServicePublication sp = new ServicePublication();
        sp.delete(publication);
        Stage s = (Stage) this.date.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/Main/Dashboard.fxml"));
        AnchorPane root = (AnchorPane) loader.load();
        DashboardController db = loader.getController();
        Scene scene = new Scene(root);
        s.setScene(scene);
        s.show();
    }

    public Object loadFXML(String s) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            return loader.load();
        } catch (IOException ex) {
            Logger.getLogger(AcceuilController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    @FXML
    private void Modifier(ActionEvent event) throws IOException {
        if (!this.titre.getText().equals("") && !this.description.getText().equals("")) {
            publication.setTitre(titre.getText());
            publication.setDescription(description.getText());
            ServicePublication sp = new ServicePublication();
            System.out.println(publication.toString());
            sp.update(publication);
            Stage s = (Stage) this.date.getScene().getWindow();
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/Main/Dashboard.fxml"));
            AnchorPane root = (AnchorPane) loader.load();
            DashboardController db = loader.getController();
            Scene scene = new Scene(root);
            s.setScene(scene);
            s.show();
        }
    }
}
