/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Presentation.Abonnement;

import Presentation.Joueurs.*;
import Entite.Joueur;
import Service.ServiceAbonnement;
import Service.ServiceJoueur;
import Utilitaire.Session;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ScrollPane;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;

/**
 * FXML Controller class
 *
 * @author eloss
 */
public class Conteneur_liste_joueurController implements Initializable {

    @FXML
    private ScrollPane scrollpane;
    @FXML
    private VBox vbox;
    private JFXTextField recherche;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        afficher_not_on_key();
        //recherche.setOnKeyReleased(this::afficher);
    }    
    public Object loadFXML(String s, Joueur p) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            loader.load();
            Case_joueur_1Controller ac = (Case_joueur_1Controller) loader.getController();
            ac.setJoueur(p);
            return loader.getRoot();
        } catch (IOException ex) {
            Logger.getLogger(getClass().getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }

    public void afficher_not_on_key(){
        List<Joueur> liste_joueur = new ArrayList<>();
        liste_joueur = new ServiceAbonnement().get_users_etleur_Joueur().get(Session.getUser());
        vbox.setPrefHeight(200*liste_joueur.size());
        vbox.getChildren().clear();
        for(Joueur J : liste_joueur){
            AnchorPane case_joueur = (AnchorPane) loadFXML("/Presentation/Abonnement/Case_joueur_1.fxml", J);
            vbox.getChildren().add(case_joueur);
        }
    }

}
