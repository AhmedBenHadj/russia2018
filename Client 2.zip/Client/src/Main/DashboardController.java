/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Entite.User;
import Presentation.Acceuil.Ajouter_ArticleController;
import Presentation.Acceuil.Mes_ArticlesController;
import Presentation.Acceuil.Modifier_ArticleController;
import Presentation.Entraineurs.Formulaire_ajout_entraineurController;
import Presentation.Entraineurs.Formulaire_modifier_entraineurController;
import Presentation.Entraineurs.Formulaire_supprimer_entraineurController;
import Presentation.Equipes.Formulaire_ajout_equipeController;
import Presentation.Equipes.Modifier_equipeController;
import Presentation.Equipes.Supprimer_equipeController;
import Presentation.Events.FormulaireAjoutEventController;
import Presentation.Galerie.Ajouter_GalerieController;
import Presentation.Joueur_P.FormulaireAjoutJoueur_PController;
import Presentation.Joueurs.Formulaire_ajout_joueurController;
import Presentation.Joueurs.Formulaire_modifier_joueurController;
import Presentation.Joueurs.Supprimer_joueurController;
import Presentation.Matchs.FormulaireAjoutMatchController;
import Presentation.Matchs.FormulaireModifMatchController;
import Presentation.Pari.MpariController;
import Presentation.Pari.PromoController;
import Presentation.Stades.FormulaireAjoutStadeController;
import Presentation.User.Ajouter_ModerateurController;
import Presentation.User.LoginController;
import Utilitaire.FXMLHandler;
import Utilitaire.Session;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;

/**
 * FXML Controller class
 *
 * @author Ghassen
 */
public class DashboardController implements Initializable {

    @FXML
    private AnchorPane chat;
    @FXML
    private JFXButton bmatch;
    @FXML
    private JFXButton bstade;
    @FXML
    private JFXButton bequipe;
    @FXML
    private JFXButton bjoueur;
    @FXML
    private JFXButton bentraineur;
    @FXML
    private JFXButton bgroupe;
    @FXML
    private JFXButton bapropos;
    @FXML
    private Rectangle logo;
    @FXML
    private Pane pmatch;
    @FXML
    private Pane pstade;
    @FXML
    private Pane pequipe;
    @FXML
    private Pane pjoueur;
    @FXML
    private Pane pentraineur;
    @FXML
    private Pane papropos;
    @FXML
    private Pane pfantasy;
    @FXML
    private Pane ppari;
    @FXML
    private Pane pgalerie;
    @FXML
    private Pane pacceuil;
    @FXML
    private Pane pgroupe;
    @FXML
    private JFXButton bacceuil;
    @FXML
    private JFXButton bgalerie;
    @FXML
    private JFXButton bpari;
    @FXML
    private JFXButton bfantasy;
    @FXML
    private Rectangle image_profil;
    @FXML
    private JFXButton se_deconnecter;

    @FXML
    private JFXButton bapplication;
    @FXML
    private AnchorPane main_anchor;
    @FXML
    private JFXButton ajouter_match;
    @FXML
    private JFXButton modifier_match;
    @FXML
    private AnchorPane emplacement_match;
    @FXML
    private JFXButton ajouter_stade;
    @FXML
    private AnchorPane emplacement_stade;
    @FXML
    private JFXButton ajouter_equipe;
    @FXML
    private JFXButton modifier_equipe;
    @FXML
    private JFXButton supprimer_equipe;
    @FXML
    private AnchorPane emplacement_equipe;
    @FXML
    private AnchorPane emplacement_joueur;
    @FXML
    private JFXButton ajouter_entraineur;
    @FXML
    private JFXButton modifier_entraineur;
    @FXML
    private JFXButton supprimer_entraineur;
    @FXML
    private AnchorPane emplacement_entraineur;
    @FXML
    private AnchorPane emplacement_groupe;
    @FXML
    private JFXButton ajouter_event;
    @FXML
    private JFXButton mesArticles;
    @FXML
    private JFXButton AjouterArticle;
    @FXML
    private JFXButton modifierArticles;
    @FXML
    private AnchorPane gestionArticle;
    @FXML
    private JFXButton ajouterGalerie;
    @FXML
    private AnchorPane aAjouterGalerie;
    @FXML
    private Pane puser;
    @FXML
    private JFXButton buser;
    @FXML
    private AnchorPane auser;
    @FXML
    private JFXButton ajouter_fiche;
    @FXML
    private JFXButton afficher_fiche;
    @FXML
    private AnchorPane emplacement_promo_pari;
    @FXML
    private JFXButton ajouter_joueur;
    @FXML
    private JFXButton modifier_joueur;
    @FXML
    private JFXButton supprimer_joueur;
    @FXML
    private JFXButton ajouter_joueur_participant;

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        User u = Session.getUser();
        Image imageprofil = new Image("http://localhost/PI/image/" + u.getImage());
        this.image_profil.setFill(new ImagePattern(imageprofil));
        switch (u.getRole()) {
            case moderateur:
                bacceuil.setVisible(false);
                bapplication.setVisible(true);
                bapropos.setVisible(true);
                bentraineur.setVisible(true);
                bequipe.setVisible(true);
                bfantasy.setVisible(false);
                bgroupe.setVisible(true);
                bjoueur.setVisible(true);
                bmatch.setVisible(true);
                bpari.setVisible(false);
                bstade.setVisible(true);
                bgalerie.setVisible(false);
                buser.setVisible(false);
                ///////
                pacceuil.setVisible(false);
                papropos.setVisible(true);
                puser.setVisible(false);
                pentraineur.setVisible(true);
                pequipe.setVisible(true);
                pfantasy.setVisible(false);
                pgalerie.setVisible(false);
                pgroupe.setVisible(true);
                pjoueur.setVisible(true);
                pmatch.setVisible(true);
                ppari.setVisible(false);
                pstade.setVisible(true);
                break;
            case journaliste:
                bacceuil.setVisible(true);
                bapplication.setVisible(true);
                bapropos.setVisible(true);
                bentraineur.setVisible(false);
                bequipe.setVisible(false);
                bfantasy.setVisible(false);
                bgroupe.setVisible(false);
                bjoueur.setVisible(false);
                bmatch.setVisible(false);
                bpari.setVisible(true);
                bstade.setVisible(false);
                bgalerie.setVisible(false);
                buser.setVisible(false);
                ///////
                pacceuil.setVisible(true);
                papropos.setVisible(true);
                puser.setVisible(false);
                pentraineur.setVisible(false);
                pequipe.setVisible(false);
                pfantasy.setVisible(false);
                pgalerie.setVisible(false);
                pgroupe.setVisible(false);
                pjoueur.setVisible(false);
                pmatch.setVisible(false);
                ppari.setVisible(true);
                pstade.setVisible(false);
                ajouter_fiche.setVisible(true);
                afficher_fiche.setVisible(false);
                break;
            case membre:
                bapplication.setVisible(true);
                bapropos.setVisible(true);
                bgalerie.setVisible(true);

                buser.setVisible(false);
                bacceuil.setVisible(false);
                bentraineur.setVisible(false);
                bequipe.setVisible(false);
                bfantasy.setVisible(false);
                bgroupe.setVisible(false);
                bjoueur.setVisible(false);
                bmatch.setVisible(false);
                bpari.setVisible(false);
                bstade.setVisible(false);
                ///////
                papropos.setVisible(true);
                pgalerie.setVisible(true);
                puser.setVisible(false);
                pacceuil.setVisible(false);
                pentraineur.setVisible(false);
                pequipe.setVisible(false);
                pfantasy.setVisible(false);
                pgroupe.setVisible(false);
                pjoueur.setVisible(false);
                pmatch.setVisible(false);
                ppari.setVisible(false);
                pstade.setVisible(false);
                break;
            case admin:
                buser.setVisible(true);
                bapropos.setVisible(true);
                bgalerie.setVisible(false);
                bacceuil.setVisible(false);
                bapplication.setVisible(true);
                bentraineur.setVisible(false);
                bequipe.setVisible(false);
                bfantasy.setVisible(false);
                bgroupe.setVisible(false);
                bjoueur.setVisible(false);
                bmatch.setVisible(false);
                bpari.setVisible(true);
                bstade.setVisible(false);
                ///////
                puser.setVisible(true);
                pacceuil.setVisible(false);
                papropos.setVisible(true);
                pentraineur.setVisible(false);
                pequipe.setVisible(false);
                pfantasy.setVisible(false);
                pgalerie.setVisible(false);
                pgroupe.setVisible(false);
                pjoueur.setVisible(false);
                pmatch.setVisible(false);
                ppari.setVisible(true);
                pstade.setVisible(false);
                pgalerie.setVisible(false);
                ajouter_fiche.setVisible(false);
                afficher_fiche.setVisible(true);
                break;
            default:
                break;
        }

        Image i = new Image("http://localhost/PI/image/Logo_russia.png");
        this.logo.setFill(new ImagePattern(i));
        this.bapplication.setOnAction(e -> {
            FXMLHandler.afficherFXML(main_anchor, "/Main/Application.fxml");
        });
    }

    @FXML
    private void handleButtonAction(ActionEvent event) {
        if (event.getSource() == bmatch) {
            pmatch.toFront();
        } else if (event.getSource() == buser) {
            puser.toFront();
        } else if (event.getSource() == bstade) {
            pstade.toFront();
        } else if (event.getSource() == bequipe) {
            pequipe.toFront();
        } else if (event.getSource() == bjoueur) {
            pjoueur.toFront();
        } else if (event.getSource() == bentraineur) {
            pentraineur.toFront();
        } else if (event.getSource() == bapropos) {
            papropos.toFront();
        } else if (event.getSource() == bfantasy) {
            pfantasy.toFront();
        } else if (event.getSource() == bpari) {
            ppari.toFront();
        } else if (event.getSource() == bgalerie) {
            pgalerie.toFront();
        } else if (event.getSource() == bacceuil) {
            pacceuil.toFront();
        }
    }

    @FXML
    private void se_deconnecter(ActionEvent event) {
        Session.setUser(null);
        FXMLHandler.afficherFXML(main_anchor, "/Main/Application.fxml");
    }

    @FXML
    private void afficher_match_1(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_match, "/Presentation/Matchs/FormulaireAjoutMatch.fxml");
    }

    @FXML
    private void afficher_match_2(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_match, "/Presentation/Matchs/FormulaireModifMatch.fxml");
    }

    @FXML
    private void afficher_match_3(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_match, "/Presentation/Events/FormulaireAjoutEvent.fxml");
    }

    @FXML
    private void afficher_stade_1(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_stade, "/Presentation/Stades/FormulaireAjoutStade.fxml");
    }

    @FXML
    private void afficher_equipe_1(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_equipe, "/Presentation/Equipes/formulaire_ajout_equipe.fxml");
    }

    @FXML
    private void afficher_equipe_2(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_equipe, "/Presentation/Equipes/modifier_equipe.fxml");
    }

    @FXML
    private void afficher_equipe_3(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_equipe, "/Presentation/Equipes/supprimer_equipe.fxml");
    }

    @FXML
    private void afficher_joueur_1(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_joueur, "/Presentation/Joueurs/formulaire_ajout_joueur.fxml");
    }

    @FXML
    private void afficher_joueur_2(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_joueur, "/Presentation/Joueurs/formulaire_modifier_joueur.fxml");
    }

    @FXML
    private void afficher_joueur_3(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_joueur, "/Presentation/Joueurs/supprimer_joueur.fxml");
    }
    @FXML
    private void afficher_entraineur_1(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_entraineur, "/Presentation/Entraineurs/Formulaire_ajout_entraineur.fxml");
    }
    @FXML
    private void afficher_entraineur_2(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_entraineur, "/Presentation/Entraineurs/Formulaire_modifier_entraineur.fxml");
    }
    @FXML
    private void afficher_entraineur_3(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_entraineur, "/Presentation/Entraineurs/Formulaire_supprimer_entraineur.fxml");
    }
    @FXML
    private void afficher_joueur_P_1(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_joueur, "/Presentation/Joueur_P/FormulaireAjoutJoueur_P.fxml");
    }
    @FXML
    private void afficher_pari_fiche(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_promo_pari, "/Presentation/Pari/promo.fxml");
    }
    @FXML
    private void afficher_pari(ActionEvent event) {
        FXMLHandler.afficherFXML(emplacement_promo_pari, "/Presentation/Pari/mpari.fxml");
    }
    @FXML
    private void mes_Article(ActionEvent event) {
        FXMLHandler.afficherFXML(gestionArticle, "/Presentation/Acceuil/Mes_Articles.fxml");
    }
    @FXML
    private void AjouterArticle(ActionEvent event) {
        FXMLHandler.afficherFXML(gestionArticle, "/Presentation/Acceuil/Ajouter_Article.fxml");
    }
    @FXML
    private void modifierArticle(ActionEvent event) {
        FXMLHandler.afficherFXML(gestionArticle, "/Presentation/Acceuil/Modifier_Article.fxml");
    }
    @FXML
    private void ajouterGalerie(ActionEvent event) {
        FXMLHandler.afficherFXML(aAjouterGalerie, "/Presentation/Galerie/Ajouter_Galerie.fxml");
    }
    @FXML
    private void ajouterModerateur(ActionEvent event) {
        FXMLHandler.afficherFXML(auser, "/Presentation/User/Ajouter_Moderateur.fxml");
    }

}
