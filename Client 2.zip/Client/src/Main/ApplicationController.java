package Main;

import Entite.*;
import Service.*;
import Utilitaire.*;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Pair;

/**
 *
 * @author Ghassen
 */
public class ApplicationController implements Initializable {

    //private Label label;
    @FXML
    private JFXButton bmatch;
    @FXML
    private JFXButton bstade;
    @FXML
    private JFXButton bjoueur;
    @FXML
    private JFXButton bequipe;
    @FXML
    private JFXButton bentraineur;
    @FXML
    private JFXButton bapropos;
    @FXML
    private Pane pmatch;
    @FXML
    private Pane pstade;
    @FXML
    private Pane pequipe;
    @FXML
    private Pane pjoueur;
    @FXML
    private Pane pentraineur;
    @FXML
    private Pane papropos;
    @FXML
    private AnchorPane chat;
    @FXML
    private Pane pfantasy;
    @FXML
    private Pane ppari;
    @FXML
    private Pane pgalerie;
    @FXML
    private Pane pacceuil;
    @FXML
    private JFXButton bacceuil;
    @FXML
    private JFXButton bgalerie;
    @FXML
    private JFXButton bpari;
    @FXML
    private JFXButton bfantasy;
    @FXML
    private Rectangle logo;
    @FXML
    private JFXButton bgroupe;
    @FXML
    private JFXButton bdashboard;
    @FXML
    private Pane pgroupe;
    @FXML
    private JFXButton se_connecter;
    @FXML
    private Rectangle image_profil;
    @FXML
    private JFXButton se_deconnecter;
    @FXML
    private AnchorPane main_anchor;
    @FXML
    private AnchorPane joueur_anchor;
    @FXML
    private AnchorPane equipes_anchor;
    @FXML
    private AnchorPane entraineur_anchor;
    @FXML
    private AnchorPane matchs_anchor;
    @FXML
    private AnchorPane agalerie;
    @FXML
    private AnchorPane aacceuil;
    private JFXTextField input;
    @FXML
    private JFXButton inscription;
    @FXML
    private Pane pprofil;
    @FXML
    private AnchorPane aprofil;
    @FXML
    private JFXButton bprofil;
    @FXML
    private AnchorPane stade_anchor;
    @FXML
    private AnchorPane anchor_pari_historique;
    @FXML
    private JFXButton afficher_mes_paris;
    @FXML
    private AnchorPane anchor_pari;
    @FXML
    private AnchorPane afantasy;
    @FXML
    private JFXButton babonnements;
    @FXML
    private Pane pabonnement;
    @FXML
    private AnchorPane aabonnement;

    @FXML
    private void handleButtonAction(ActionEvent event) {
        if (event.getSource() == bmatch) {
            pmatch.toFront();
        } else if (event.getSource() == bstade) {
            pstade.toFront();
        } else if (event.getSource() == bequipe) {
            pequipe.toFront();
        } else if (event.getSource() == bjoueur) {
            pjoueur.toFront();
        } else if (event.getSource() == bentraineur) {
            pentraineur.toFront();
        } else if (event.getSource() == bapropos) {
            papropos.toFront();
        } else if (event.getSource() == bfantasy) {
            pfantasy.toFront();
        } else if (event.getSource() == bpari) {
            ppari.toFront();
        } else if (event.getSource() == bgalerie) {
            pgalerie.toFront();
        } else if (event.getSource() == bacceuil) {
            pacceuil.toFront();
        } else if (event.getSource() == bprofil) {
            pprofil.toFront();
        } else if (event.getSource() == bfantasy) {
            pfantasy.toFront();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        if (Session.getUser() != null) {
            connect(Session.getUser());
            Image i = new Image("http://localhost/PI/image/" + Session.getUser().getImage());
            this.image_profil.setFill(new ImagePattern(i));
        }
        this.bprofil.setVisible(false);
        this.babonnements.setVisible(false);
        Image i = new Image("http://localhost/PI/image/Logo_russia.png");

        this.logo.setFill(new ImagePattern(i));
        pacceuil.toFront();
        this.bdashboard.setOnAction(e -> {
            FXMLHandler.afficherFXML(main_anchor, "/Main/Dashboard.fxml");
        });
        FXMLHandler.afficherFXML(joueur_anchor, "/Presentation/Joueurs/conteneur_liste_joueur.fxml");
        FXMLHandler.afficherFXML(stade_anchor, "/Presentation/Stades/Tout_les_stades.fxml");
        FXMLHandler.afficherFXML(matchs_anchor, "/Presentation/Matchs/Tout_les_matchs.fxml");
        FXMLHandler.afficherFXML(entraineur_anchor, "/Presentation/Entraineurs/Conteneur_liste_entraineur.fxml");
        FXMLHandler.afficherFXML(equipes_anchor, "/Presentation/Equipes/Conteneur_liste_equipe.fxml");
        FXMLHandler.afficherFXML(anchor_pari, "/Presentation/Pari/pari.fxml");
        FXMLHandler.afficherFXML(agalerie, "/Presentation/Galerie/Galerie.fxml");
        FXMLHandler.afficherFXML(aacceuil, "/Presentation/Acceuil/Acceuil.fxml");
        FXMLHandler.afficherFXML(chat, "/Presentation/User/Chatv2.fxml");
    }

    @FXML
    private void se_connecter(ActionEvent event) {
        Dialog<Pair<String, String>> dialog = new Dialog<>();
        dialog.setTitle("Login ");

// Set the button types.
        ButtonType loginButtonType = new ButtonType("Se connecter", ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().addAll(loginButtonType, ButtonType.CANCEL);

// Create the username and password labels and fields.
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setPadding(new Insets(20, 150, 10, 10));

        TextField username = new TextField();
        username.setPromptText("Username/Email");
        PasswordField password = new PasswordField();
        password.setPromptText("Password");

        grid.add(new Label("Username:"), 0, 0);
        grid.add(username, 1, 0);
        grid.add(new Label("Password:"), 0, 1);
        grid.add(password, 1, 1);

// Enable/Disable login button depending on whether a username was entered.
        Node loginButton = dialog.getDialogPane().lookupButton(loginButtonType);
        loginButton.setDisable(true);

// Do some validation (using the Java 8 lambda syntax).
        username.textProperty().addListener((observable, oldValue, newValue) -> {
            loginButton.setDisable(newValue.trim().isEmpty());
        });

        dialog.getDialogPane().setContent(grid);

// Request focus on the username field by default.
        Platform.runLater(() -> username.requestFocus());

// Convert the result to a username-password-pair when the login button is clicked.
        dialog.setResultConverter(dialogButton -> {
            if (dialogButton == loginButtonType) {
                return new Pair<>(username.getText(), password.getText());
            }
            return null;
        });

        Optional<Pair<String, String>> result = dialog.showAndWait();

        result.ifPresent(usernamePassword -> {
            ServiceUser su = new ServiceUser();
            User u = su.retrieveEmail(usernamePassword.getKey());
            if (u != null && Password.checkPassword(usernamePassword.getValue(), u.getMdp())) {
                connect(u);
            } else {
                u = su.retrieveUsername(usernamePassword.getKey());
                if (u != null && Password.checkPassword(usernamePassword.getValue(), u.getMdp())) {
                    connect(u);
                } else {
                    System.out.println("nooo");
                }
            }
            System.out.println("Username=" + usernamePassword.getKey() + ", Password=" + usernamePassword.getValue());
        });

    }

    @FXML
    private void se_deconnecter(ActionEvent event) throws IOException {
        Session.setUser(null);
        FXMLHandler.goToMainStage(logo, "/Main/Application.fxml");
        this.babonnements.setVisible(false);
    }

    public void connect(User u) {
        ServiceUser su = new ServiceUser();
        u.setConnecte(User.Connecte.ON);
        su.update(u);
        Session.setUser(u);
        this.inscription.setVisible(false);
        this.bpari.setVisible(true);
        this.bfantasy.setVisible(true);
        Image i = new Image("http://localhost/PI/image/" + u.getImage());
        this.image_profil.setFill(new ImagePattern(i));
        this.image_profil.setVisible(true);
        this.se_connecter.setVisible(false);
        this.se_deconnecter.setVisible(true);
        this.bdashboard.setVisible(true);
        if (u.getRole().equals(User.Role.membre)) {
            this.bdashboard.setText("Ma Galerie");
        } else {
            this.bdashboard.setText("Dashboard");
        }
        FXMLHandler.afficherFXML(joueur_anchor, "/Presentation/Joueurs/conteneur_liste_joueur.fxml");
        FXMLHandler.afficherFXML(anchor_pari, "/Presentation/Pari/pari.fxml");
        FXMLHandler.afficherFXML(anchor_pari_historique, "/Presentation/Pari/upari.fxml");
        bprofil.setVisible(true);
        babonnements.setVisible(true);
        FXMLHandler.afficherFXML(chat, "/Presentation/User/Chatv2.fxml");
    }

    @FXML
    private void profil(ActionEvent event) {
        FXMLHandler.afficherFXML(aprofil, "/Presentation/User/Profil.fxml");
        pprofil.toFront();
    }

    @FXML
    private void inscription(ActionEvent event) throws IOException {
        FXMLLoader l = new FXMLLoader(getClass().getResource("/Presentation/User/Siign_up.fxml"));
        Parent p = (Parent) l.load();
        Stage s = new Stage();
        s.setScene(new Scene(p));
        s.show();
    }

    @FXML
    private void afficher_mes_paris(ActionEvent event) {
    }

    @FXML
    private void test(ActionEvent event) {
        FXMLHandler.afficherFXML(afantasy, "/Presentation/Fantasy/AjoutFantasyEquipe.fxml");
        pfantasy.toFront();
    }

    @FXML
    private void mes_abonnements(ActionEvent event) {
        FXMLHandler.afficherFXML(aabonnement, "/Presentation/Abonnement/conteneur_liste_joueur.fxml");
        pabonnement.toFront();
    }

}
