/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TCPClient;

import Utilitaire.UNZipper;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

/**
 *
 * @author Ghassen
 */
public class ImageReceiver {

    private final static String SERVERIP = "127.0.0.1";
    private final static int SERVERPORT = 3248;
    private final static String FILEOUTPUT = "image.rar";

    public static void get() {
        byte[] aByte = new byte[1];
        int bytesRead;
        Socket clientSocket = null;
        InputStream is = null;
        try {
            clientSocket = new Socket(SERVERIP, SERVERPORT);
            is = clientSocket.getInputStream();
        } catch (IOException ex) {
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if (is != null) {
            FileOutputStream fos = null;
            BufferedOutputStream bos = null;
            try {
                fos = new FileOutputStream(FILEOUTPUT);
                bos = new BufferedOutputStream(fos);
                bytesRead = is.read(aByte, 0, aByte.length);
                do {
                    baos.write(aByte);
                    bytesRead = is.read(aByte);
                } while (bytesRead != -1);
                bos.write(baos.toByteArray());
                bos.flush();
                bos.close();
                clientSocket.close();
                UNZipper.unzipImages();
            } catch (IOException ex) {
            }
        }
        /*Thread thread = new Thread(new ImageReceiver());
        thread.start();*/
    }

    //@Override
    /*public void run() {
        byte[] aByte = new byte[1];
        int bytesRead;
        Socket clientSocket = null;
        InputStream is = null;
        try {
            clientSocket = new Socket(SERVERIP, SERVERPORT);
            is = clientSocket.getInputStream();
        } catch (IOException ex) {
        }
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        if (is != null) {
            FileOutputStream fos = null;
            BufferedOutputStream bos = null;
            try {
                fos = new FileOutputStream(FILEOUTPUT);
                bos = new BufferedOutputStream(fos);
                bytesRead = is.read(aByte, 0, aByte.length);
                do {
                    baos.write(aByte);
                    bytesRead = is.read(aByte);
                } while (bytesRead != -1);
                bos.write(baos.toByteArray());
                bos.flush();
                bos.close();
                clientSocket.close();
                UNZipper.unzipImages();
            } catch (IOException ex) {
            }
        }
    }*/
}
