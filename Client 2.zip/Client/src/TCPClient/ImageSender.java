/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TCPClient;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;

/**
 *
 * @author Ghassen
 */
public class ImageSender {

    private Socket s;

    public ImageSender(String host, int port, File file) {
        try {
            s = new Socket(host, port);
            sendFile(file);
        } catch (IOException e) {
        }
    }
    public ImageSender(String host, int port, File file,String name) {
        try {
            s = new Socket(host, port);
            sendFile(file,name);
        } catch (IOException e) {
        }
    }
    public void sendFile(File file,String name) throws IOException {
        try (DataOutputStream dos = new DataOutputStream(s.getOutputStream())) {
            DataOutputStream d = new DataOutputStream(dos);
            d.writeUTF(name);
            FileInputStream fis = new FileInputStream(file);
            byte[] buffer = new byte[4096];
            while (fis.read(buffer) > 0) {
                d.write(buffer);
            }
            fis.close();
        }
    }
    public void sendFile(File file) throws IOException {
        try (DataOutputStream dos = new DataOutputStream(s.getOutputStream())) {
            DataOutputStream d = new DataOutputStream(dos);
            System.out.println(file.getName());
            d.writeUTF(file.getName());
            FileInputStream fis = new FileInputStream(file);
            byte[] buffer = new byte[4096];
            while (fis.read(buffer) > 0) {
                d.write(buffer);
            }
            fis.close();
        }
    }
}
