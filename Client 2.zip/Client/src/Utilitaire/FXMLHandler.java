/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilitaire;

import Presentation.User.LoginController;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

/**
 *
 * @author Ghassen
 */
public class FXMLHandler {

    public Object loadFXML(String s) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(s));
        try {
            loader.load();
            return loader.getRoot();
        } catch (IOException ex) {
            Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    public static void afficherFXML(AnchorPane anchorpane,String path) {
        AnchorPane ap = (AnchorPane) new FXMLHandler().loadFXML(path);
        anchorpane.getChildren().clear();
        anchorpane.getChildren().addAll(ap);
        ap.prefWidthProperty().bind(anchorpane.widthProperty());
    }
    public static void goToMainStage(Node node,String path){
        Stage s = (Stage) node.getScene().getWindow();
        AnchorPane ap = (AnchorPane) new FXMLHandler().loadFXML(path);
        Scene scene = new Scene(ap);
        s.setScene(scene);
        s.show();
    }
}
