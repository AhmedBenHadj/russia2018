/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilitaire;
import com.nexmo.client.*;
import com.nexmo.client.auth.AuthMethod;
import com.nexmo.client.auth.TokenAuthMethod;
import com.nexmo.client.sms.SmsSubmissionResult;
import com.nexmo.client.sms.messages.TextMessage;
import java.io.IOException;
/**
 *
 * @author skanderbejaoui
 */
public class SMS {

    /**
     * @param args the command line arguments
     */
    public static void creer() throws IOException, NexmoClientException {
        // TAuthMethod auth = new TokenAuthMethod(API_KEY, API_SECRET);
AuthMethod auth = new TokenAuthMethod("760e1d37","IHNJo2w0aF9nPfL3");
NexmoClient client = new NexmoClient(auth);
SmsSubmissionResult[] responses = client.getSmsClient().submitMessage(new TextMessage(
        "Russie_2018",
        "+21628428425",
        "Felicitations,vous avez gagné un pari!"));
for (SmsSubmissionResult response : responses) {
    System.out.println(response);
}
    }
    
}
