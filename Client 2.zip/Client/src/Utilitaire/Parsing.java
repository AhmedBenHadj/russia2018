/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilitaire;

import Configuration.MyConnexion;
import Entite.Entraineur;
import Entite.Equipe;
import Entite.Groupe;
import Entite.Joueur;
import Entite.Match;
import Entite.Score;
import Service.ServiceEntraineur;
import Service.ServiceEquipe;
import Service.ServiceGroupe;
import Service.ServiceJoueur;
import Service.ServiceMatch;
import Service.ServiceScore;
import Service.ServiceStade;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author eloss
 */
public class Parsing {
    Connection cnx;
    PreparedStatement pst;
    private Open_file open_file ;
    private List<Joueur> liste_joueur ;
    private List<Equipe> liste_equipe ;
    private List<Entraineur> liste_entraineur ;
    private List<Match> liste_matchs ;
    public Parsing(String nom_fichier) {
        cnx = MyConnexion.getInstance();
        open_file = new Open_file(nom_fichier);
        this.open_file.readFile();
        liste_equipe = new ArrayList<>();
        liste_joueur = new ArrayList<>();
        liste_entraineur = new ArrayList<>();
        liste_matchs = new ArrayList<>();
    }
    
    public void setAllPlayers(){
        for(String line : open_file.getRecords()){
            Joueur J = new Joueur();
            line = line.replaceAll("\t"," ");
                for(String ch : line.split(" ")){                   
                    if(!ch.isEmpty()){
                        if(ch.startsWith("Nu:")){
                            ch = ch.replace("Nu:","");
                            ch = ch.trim();
                            J.setNumero(Integer.parseInt(ch));
                        }
                        else if(ch.startsWith("P:")){
                            ch = ch.replace("P:", "");
                            ch=ch.trim();
                            J.setPoste(ch);
                        }
                        else if(ch.startsWith("Pr:")){
                            ch = ch.replace("Pr:", "");
                            ch=ch.trim();
                            J.setPrenom(ch);
                        }
                        else if(ch.startsWith("N:")){
                            ch = ch.replace("N:", "");
                            ch = ch.trim();
                            J.setNom(ch);
                        }
                        else if(ch.startsWith("A:")){
                            ch = ch.replace("A:", "");
                            ch = ch.trim();
                            J.setAge(Integer.parseInt(ch));
                        }
                        else if(ch.startsWith("E:")){
                            ch = ch.replace("E:", "");
                            ch = ch.trim();
                            J.setClub(ch);
                        }  
                        else if(ch.startsWith("Eq:")){
                            ch = ch.replace("Eq:", "");
                            ch = ch.trim();
                            J.setEquipe(new Service.ServiceEquipe().get_by_name(ch));
                        }
                    }
                }           
            liste_joueur.add(J);
        }
    }

    public void Ajout_AllPlayer(){
        ServiceJoueur SJ = new ServiceJoueur();
        for(Joueur J : liste_joueur){
            SJ.ajouter(J);
        }
    }
    
    public void setAllTeams(){
        for(String line : open_file.getRecords()){
            Equipe E = new Equipe();
            line = line.replaceAll("\t"," ");
            Groupe G = new Groupe();
            Entraineur En = new Entraineur();
            for(String ch : line.split(" ")){              
                if(!ch.isEmpty()){
                    if(ch.startsWith("Group:")){
                        ch =ch.replace("Group:","");
                        ch =ch.trim();
                        G.setNom(ch);
                        //new ServiceGroupe().ajouter_Groupe(G);
                    }
                    else if(ch.startsWith("E:")){
                        ch= ch.replace("E:","");
                        ch = ch.trim();
                        En.setPrenom(ch);
                    }
                    else{
                        ch =ch.trim() ;
                        E.setNom(ch);
                        E.setGroupe(new ServiceGroupe().get(G.getNom()));
                        E.setEntraineur(new ServiceEntraineur().get_by_name(En.getPrenom()));
                        new ServiceEquipe().ajouter(E);
                    }
                }
            }           
        }
    }
    public void AjouterAllTeams(){
        ServiceEquipe SE = new ServiceEquipe() ;
        for( Equipe E : liste_equipe){
            //System.out.println(E);
        }
    }
    public void setAllEntraineur(){
        for(String line : open_file.getRecords()){
            Entraineur E = new Entraineur();
            line = line.replaceAll("\t"," ");
                for(String ch : line.split(" ")){                   
                    if(!ch.isEmpty()){
                        if(ch.startsWith("N:")){
                            ch = ch.replace("N:","");
                            ch = ch.trim();
                            E.setNom(ch);                          
                        }
                        else if(ch.startsWith("P:")){
                            ch = ch.replace("P:", "");
                            ch=ch.trim();
                            E.setPrenom(ch);
                        }
                    }
                }  
            liste_entraineur.add(E);
        }
    }
    public void setAllMatchs(){
        for(String line : open_file.getRecords()){
            int i=1 ;
            Match M = new Match();
            if(!line.isEmpty()){
                line = line.replaceAll("\t"," ");
                    for(String ch : line.split(" ")){                   
                        if(!ch.isEmpty()){
                            if(ch.startsWith("G:")){
                                ch = ch.replace("G:","");
                                ch = ch.trim();
                                M.setG(new ServiceGroupe().get(ch));                          
                            }
                            else if(ch.startsWith("D:")){
                                ch = ch.replace("D:", "");
                                ch=ch.trim();
                                Date date =Date.valueOf("2018-06-"+ch);
                                M.setDate(date);
                            }
                            else if(ch.startsWith("T:")){
                                ch = ch.replace("T:", "");
                                ch=ch.trim();
                                ch+=":00";
                                M.setHeure(Time.valueOf(ch));
                            }
                            else if(ch.startsWith("E1:")){
                                ch = ch.replace("E1:", "");
                                ch=ch.trim();
                                M.setE1(new ServiceEquipe().get_by_name(ch));
                            }
                            else if(ch.startsWith("E2:")){
                                ch = ch.replace("E2:", "");
                                ch=ch.trim();
                                M.setE2(new ServiceEquipe().get_by_name(ch));
                            }
                            else if(ch.startsWith("E1:")){
                                ch = ch.replace("E1:", "");
                                ch=ch.trim();
                                M.setE1(new ServiceEquipe().get_by_name(ch));
                            }
                        }
                    }  
                    M.setId(i);
                    ServiceStade SD = new ServiceStade() ;
                    M.setS(SD.get(SD.recuperer_Id_par_nom("Centralniy")));
                    M.setEtat(Match.EtatMatch.Debut);
                    M.setType(Match.progress.pool);
                    ServiceMatch SM = new ServiceMatch() ;
                    SM.ajouter_Match(M);
                    ServiceScore SC=new ServiceScore();
                    Score S=new Score();                  
                    S.setId(M.getId());
                    S.setA(0);
                    S.setB(0);
                    SC.ajouter_Score(S);
                liste_matchs.add(M);
                i++;
            }           
        }
    }
    public void AjoutAllMatchs(){
        ServiceMatch SE = new ServiceMatch();
        for(Match E: liste_matchs){
            SE.ajouter_Match(E);
        }
    }
    public void AjoutAllEntraineur(){
        ServiceEntraineur SE = new ServiceEntraineur();
        for(Entraineur E: liste_entraineur){
            SE.ajouter(E);
        }
    }
    
    public Open_file getOpen_file() {
        return open_file;
    }

    public void setOpen_file(Open_file open_file) {
        this.open_file = open_file;
    }

    public List<Joueur> getListe_joueur() {
        return liste_joueur;
    }

    public void setListe_joueur(List<Joueur> liste_joueur) {
        this.liste_joueur = liste_joueur;
    }

    public List<Equipe> getListe_equipe() {
        return liste_equipe;
    }

    public void setListe_equipe(List<Equipe> liste_equipe) {
        this.liste_equipe = liste_equipe;
    }

    public List<Entraineur> getListe_entraineur() {
        return liste_entraineur;
    }

    public void setListe_entraineur(List<Entraineur> liste_entraineur) {
        this.liste_entraineur = liste_entraineur;
    }

    public List<Match> getListe_matchs() {
        return liste_matchs;
    }

    public void setListe_matchs(List<Match> liste_matchs) {
        this.liste_matchs = liste_matchs;
    }
}
