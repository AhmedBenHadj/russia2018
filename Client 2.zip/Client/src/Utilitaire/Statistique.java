/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilitaire;

import Entite.Evenement;
import Entite.Joueur;
import Service.ServiceEvenement;
import java.util.ArrayList;
import java.util.List;
import javafx.collections.FXCollections;
import javafx.scene.chart.PieChart;

/**
 *
 * @author eloss
 */
public class Statistique {
    private Joueur joueur ;
    public List<PieChart> getAll(){
        List<PieChart> liste_chart = new ArrayList<>();
        liste_chart.add(this.GetPie_but());
        liste_chart.add(this.GetPie_carton());
        return liste_chart;
    }
    public PieChart GetPie_but(){
        PieChart chart = new PieChart(
          FXCollections.observableArrayList(
            new PieChart.Data("But marqué",         this.nb_evenement_marque()),
            new PieChart.Data("But non marqué",         this.nb_evenement() - this.nb_evenement_marque())
            //new PieChart.Data("nombre d'action",  this.nb_evenement())
          )      
        );
        chart.setTitle("Pourcentage de but marqué "+joueur.getNom());
        chart.setPrefHeight(490);
        chart.setPrefWidth(600);
        return chart ;
    }
    public PieChart GetPie_carton(){
        PieChart chart = new PieChart(
          FXCollections.observableArrayList(
            new PieChart.Data("Carton jaune",         this.nb_evenement_carte_jaune()),
            new PieChart.Data("Carton rouge",         this.nb_evenement_carte_rouge()),
            new PieChart.Data("Pas de carte",  this.nb_evenement_pas_carte())
          )      
        );
        chart.setTitle("Pourcentage d'avertissement de  "+joueur.getNom());
        chart.setPrefHeight(490);
        chart.setPrefWidth(600);
        return chart ;
    }
    private int nb_evenement(){
        return new ServiceEvenement().get_evenement_by_joueur(joueur).size() ;
    }
    private int nb_evenement_marque(){
        int somme=0 ;
        ServiceEvenement SE = new ServiceEvenement();
        for(Evenement E : SE.get_evenement_by_joueur(joueur)){
            if(E.getBut() == 1){
                somme++ ;
            }
        }
        return somme ;
    }
    private int nb_evenement_carte_jaune(){
        int somme=0 ; 
        ServiceEvenement SE = new ServiceEvenement();
        for(Evenement E : SE.get_evenement_by_joueur(joueur)){
            if(E.getCarton().equals(Evenement.TypeCarton.Jaune)){
                somme++ ;
            }
        }
        return somme ;
    }
    private int nb_evenement_carte_rouge(){
        int somme=0 ; 
        ServiceEvenement SE = new ServiceEvenement();
        for(Evenement E : SE.get_evenement_by_joueur(joueur)){
            if(E.getCarton().equals(Evenement.TypeCarton.Rouge)){
                somme++ ;
            }
        }
        return somme ;
    }
    private int nb_evenement_pas_carte(){
        int somme=0 ; 
        ServiceEvenement SE = new ServiceEvenement();
        for(Evenement E : SE.get_evenement_by_joueur(joueur)){
            if(E.getCarton().equals(Evenement.TypeCarton.PasC)){
                somme++ ;
            }
        }
        return somme ;
    }
    public void setjoueur(Joueur j){
        this.joueur = j ;
    }
}
