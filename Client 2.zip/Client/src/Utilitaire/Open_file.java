/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilitaire;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author eloss
 */
public class Open_file {
    List<String> records ;
    String filename ;
    public Open_file(String filename){
        this.filename = filename ;
        this.records = new ArrayList<>();
    }

    public List<String> getRecords() {
        return records;
    }

    public void setRecords(List<String> records) {
        this.records = records;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }
    public void readFile()
    {
    List<String> records = new ArrayList<>();
    try
    {
        BufferedReader reader = new BufferedReader(new FileReader(this.filename));
        String line;
        while ((line = reader.readLine()) != null)
        {
            records.add(line);
            //System.out.println("test");
        }
        reader.close();
    this.records = records;
    }
    catch (Exception e)
    {
        System.err.format("Exception occurred trying to read '%s'.", this.filename);
        e.printStackTrace();
       
    }
    }
    @Override
    public String toString(){
        String ch="" ;
        for(String s : records){
            ch+=s+'\n';
        }
        return ch ;
    }
    
    public String No_White_Space(String lane){
        lane=lane.replaceAll(" ",""); //supprimer les espaces
        //lane=lane.replace(Begin,"");//Supprimer le "Begin"
        lane=lane.trim();//Supprimer l'espace du début et de fin
        return lane ;
    }
}
