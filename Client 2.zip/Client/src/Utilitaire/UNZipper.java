/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Utilitaire;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 *
 * @author Ghassen
 */
public class UNZipper {

    private static final String IMG_REP = "C:\\Users\\elossofa\\Desktop\\Bouhmid\\Client\\image\\";

    public static void clean(String rep) {
        File imagerep = new File(rep);
        List<File> imagelist = new ArrayList<File>();
        getAllImages(imagerep, imagelist);
        for (File file : imagelist) {
            file.delete();
        }

    }

    public static void getAllImages(File imagerep, List<File> imagelist) {
        File[] files = imagerep.listFiles();
        for (File file : files) {
            imagelist.add(file);
            if (file.isDirectory()) {
                getAllImages(file, imagelist);
            }
        }
    }

    public static void unzipImages() {
        String rep = IMG_REP;
        clean(rep);
        try {
            try (ZipFile zipFile = new ZipFile("image.rar")) {
                Enumeration<?> enu = zipFile.entries();
                while (enu.hasMoreElements()) {
                    ZipEntry zipEntry = (ZipEntry) enu.nextElement();
                    String name = rep + zipEntry.getName();
                    long size = zipEntry.getSize();
                    long compressedSize = zipEntry.getCompressedSize();
                    System.out.printf("name: %-20s | size: %6d | compressed size: %6d\n",
                            name, size, compressedSize);
                    File file = new File(name);
                    if (name.endsWith("/")) {
                        file.mkdirs();
                        continue;
                    }
                    File parent = file.getParentFile();
                    if (parent != null) {
                        parent.mkdirs();
                    }
                    FileOutputStream fos;
                    try (InputStream is = zipFile.getInputStream(zipEntry)) {
                        fos = new FileOutputStream(file);
                        byte[] bytes = new byte[1024];
                        int length;
                        while ((length = is.read(bytes)) >= 0) {
                            fos.write(bytes, 0, length);
                        }
                    }
                    fos.close();

                }
            }
        } catch (IOException e) {
        }
    }
}
