/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package IService;

import Entités.Entraineur;
import Entités.Equipe;
import Entités.Joueur;
import java.util.List;

/**
 *
 * @author quickstrikes96
 */
public interface IServiceJoueur {
    boolean ajouter(Joueur J) ;
    void modifier(int id,Equipe equipe,String nom,String prenom ,int age ,String poste,int numero,String club) ;
    boolean supprimer(Joueur j);
    Joueur get(int id);
    List<Joueur> getALL();
    List<Joueur> D_chercher(String nom);
    Equipe get_equipe(Joueur j);
    Entraineur get_entraineur(Joueur j);
    List<Joueur> get_tri_selon(String champs);
    
}
