/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package russie2018;

import Entités.Joueur;
import Entités.JoueurFantasy;
import Service.ServiceJoueurFantasy;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author quickstrikes96
 */
public class Russie2018 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ServiceJoueurFantasy F = new ServiceJoueurFantasy();
        Joueur b = new Joueur();
        b.setId(8);
        
        JoueurFantasy JF = new JoueurFantasy(1,b,20,30,40,50);
        JF.getJoueur().setId(b.getId());
        System.out.println(JF.getEtat());
        F.modifier(JF);
        // F.ajouter_joueur(JF);
        //JF.setId(4);
       // System.out.println(JF.getId());
        //F.eliminer_joueur(JF);
        List<JoueurFantasy> liste = new ArrayList<>();
        liste = F.afficher_tous();
        for (JoueurFantasy joueurFantasy : liste) {
            System.out.println(joueurFantasy.getPrix());
        }
        
        
        
    }
    
}
