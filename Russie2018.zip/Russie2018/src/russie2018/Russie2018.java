/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package russie2018;

import Entités.EquipeFantasy;
import Entités.Joueur;
import Entités.JoueurFantasy;
import Entités.User;
import Service.ServiceEquipeFantasy;
import Service.ServiceJoueurFantasy;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author quickstrikes96
 */
public class Russie2018 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ServiceJoueurFantasy F = new ServiceJoueurFantasy();
        Joueur b = new Joueur();
        List<EquipeFantasy> FEquipes = new ArrayList<>();
        b.setId(8);
        
        JoueurFantasy JF = new JoueurFantasy(1,b, (ArrayList<EquipeFantasy>) FEquipes,20,30,40,50);
        JF.getJoueur().setId(b.getId());
       // System.out.println(JF.getEtat());
       // F.modifier(JF);
        F.ajouter_joueur(JF,2);
        //JF.setId(4);
       // System.out.println(JF.getId());
        //F.eliminer_joueur(JF);
        List<JoueurFantasy> liste = new ArrayList<>();
        liste = F.afficher_tous();
        for (JoueurFantasy joueurFantasy : liste) {
            System.out.println(joueurFantasy.getPrix());
        }
        
        
        ServiceEquipeFantasy E = new ServiceEquipeFantasy();
        User u = new User();
        u.setId(1);
        
        EquipeFantasy EF = new EquipeFantasy(1,u,"rzouga's team");
        EF.getUser().setId(u.getId());
      //  E.creer_equipefantasy(EF);
        
        
        
    }
    
}
