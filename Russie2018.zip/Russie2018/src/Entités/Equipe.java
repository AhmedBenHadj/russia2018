/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entités;

/**
 *
 * @author quickstrikes96
 */
public class Equipe {
    private int id;
    private Entraineur Entraineur;
    private String nom;
    private String drapeau;
    private String maillot;

    public Equipe(Entraineur Entraineur, String nom, String drapeau, String maillot) {
        
        this.Entraineur = Entraineur;
        this.nom = nom;
        this.drapeau = drapeau;
        this.maillot = maillot;
    }
    
     public Equipe(int id ,Entraineur Entraineur, String nom, String drapeau, String maillot) {
        
        this.Entraineur = Entraineur;
        this.nom = nom;
        this.drapeau = drapeau;
        this.maillot = maillot;
    }

   

    public Equipe() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getDrapeau() {
        return drapeau;
    }

    public void setDrapeau(String drapeau) {
        this.drapeau = drapeau;
    }

    public String getMaillot() {
        return maillot;
    }

    public void setMaillot(String maillot) {
        this.maillot = maillot;
    }

    public void setEntraineur(Entraineur Entraineur) {
        this.Entraineur=Entraineur;
    }

    public Entraineur getEntraineur() {
        return Entraineur;
    }
    
    
    
}
