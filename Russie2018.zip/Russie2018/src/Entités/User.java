/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entités;

import java.sql.Date;

/**
 *
 * @author quickstrikes96
 */
public class User {
    
    
    @Override
    public String toString() {
        return "User{" + "id=" + id + ", etat=" + etat + ", type=" + type + ", date_creation=" + date_creation + ", nom=" + nom + ", prenom=" + prenom + ", username=" + username + ", email=" + email + ", mdp=" + mdp + ", image=" + image + ", role=" + role + ", connecte=" + connecte + '}';
    }

    /**
     * les roles des utilisateurs
     */
    public enum Role {

        /**
         * role admin
         */
        admin,

        /**
         * role moderateur
         */
        moderateur,

        /**
         * role journaliste
         */
        journaliste,

        /**
         * role membre
         */
        membre
    }

    /**
     * user connecte 
     */
    public enum Connecte{

        /**
         *
         */
        ON,

        /**
         *
         */
        OFF
    }
    private int id,etat,type;
    private Date date_creation;
    private String nom,prenom,username,email,mdp,image;
    private Role role;
    private Connecte connecte;
    
    /**
     * Constructeur
     * @param id
     * @param etat
     * @param type
     * @param date_creation
     * @param nom
     * @param prenom
     * @param username
     * @param email
     * @param mdp
     * @param image
     * @param role
     * @param connecte
     
     */
    public User(int id, int etat, int type, Date date_creation, String nom, String prenom, String username, String email, String mdp, String image, Role role, Connecte connecte) {
        this.id = id;
        this.etat = etat;
        this.type = type;
        this.date_creation = date_creation;
        this.nom = nom;
        this.prenom = prenom;
        this.username = username;
        this.email = email;
        this.mdp = mdp;
        this.image = image;
        this.role = role;
        this.connecte = connecte;
        
    }
    public User(int etat, int type, Date date_creation, String nom, String prenom, String username, String email, String mdp, String image, Role role, Connecte connecte) {
        this.etat = etat;
        this.type = type;
        this.date_creation = date_creation;
        this.nom = nom;
        this.prenom = prenom;
        this.username = username;
        this.email = email;
        this.mdp = mdp;
        this.image = image;
        this.role = role;
        this.connecte = connecte;
        
    }

    /**
     * Constructeur par defaut
     */
    public User() {
        
    }


    /**
     *
     * @return type
     */
    public int getType() {
        return type;
    }

    /**
     *
     * @param type
     */
    public void setType(int type) {
        this.type = type;
    }     

    /**
     *
     * @return id
     */
    public int getId() {
        return id;
    }

    /**
     *
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     *
     * @return etat
     */
    public int getEtat() {
        return etat;
    }

    /**
     *
     * @param etat
     */
    public void setEtat(int etat) {
        this.etat = etat;
    }

    /**
     *
     * @return date creation du compte
     */
    public Date getDate_creation() {
        return date_creation;
    }

    /**
     *
     * @param date_creation
     */
    public void setDate_creation(Date date_creation) {
        this.date_creation = date_creation;
    }

    /**
     *
     * @return nom
     */
    public String getNom() {
        return nom;
    }

    /**
     *
     * @param nom
     */
    public void setNom(String nom) {
        this.nom = nom;
    }

    /**
     *
     * @return
     */
    public String getPrenom() {
        return prenom;
    }

    /**
     *
     * @param prenom
     */
    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    /**
     *
     * @return username
     */
    public String getUsername() {
        return username;
    }

    /**
     *
     * @param username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     *
     * @return email
     */
    public String getEmail() {
        return email;
    }

    /**
     *
     * @param email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     *
     * @return mot de passe
     */
    public String getMdp() {
        return mdp;
    }

    /**
     *
     * @param mdp
     */
    public void setMdp(String mdp) {
        this.mdp = mdp;
    }

    /**
     *
     * @return lien image
     */
    public String getImage() {
        return image;
    }

    /**
     *
     * @param image
     */
    public void setImage(String image) {
        this.image = image;
    }

    /**
     *
     * @return role
     */
    public Role getRole() {
        return role;
    }

    /**
     *
     * @param role
     */
    public void setRole(Role role) {
        this.role = role;
    }

    /**
     *
     * @return connecte
     */
    public Connecte getConnecte() {
        return connecte;
    }

    /**
     *
     * @param connecte
     */
    public void setConnecte(Connecte connecte) {
        this.connecte = connecte;
    }
    @Override
    public int hashCode(){
        return 5 ;
    }
    
}
