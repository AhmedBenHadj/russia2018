/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entités;

/**
 *
 * @author quickstrikes96
 */
public class Joueur {
    private int id;
    private Equipe Equipe;
    private String nom;
    private String prenom;
    private int age;
    private String poste;
    private int numero;
    private String club;

    public Joueur(Equipe Equipe, String nom, String prenom, int age, String poste, int numero, String club) {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPoste() {
        return poste;
    }

    public void setPoste(String poste) {
        this.poste = poste;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public String getClub() {
        return club;
    }

    public void setClub(String club) {
        this.club = club;
    }

    
    
    public Joueur(int id, Equipe Equipe, String nom, String prenom, int age, String poste, int numero, String club) {
        this.id = id;
        this.Equipe = new Equipe();
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.poste = poste;
        this.numero = numero;
        this.club = club;
    }
    
        public Joueur(String nom, String prenom, int age, String poste, int numero, String club) {
        this.nom = nom;
        this.prenom = prenom;
        this.age = age;
        this.poste = poste;
        this.numero = numero;
        this.club = club;
    }
    
    public Joueur(){}

    public Equipe getEquipe() {
        return Equipe;
    }
    
    public void setEquipe(Equipe Equipe) {
        this.Equipe = Equipe;
    }

    @Override
    public String toString() {
        return "Joueur{" + "id=" + id + ", Equipe=" + Equipe + ", nom=" + nom + ", prenom=" + prenom + ", age=" + age + ", poste=" + poste + ", numero=" + numero + ", club=" + club + '}';
    }
    
    
    
}
