/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Entités.EquipeFantasy;
import IService.IServiceEquipeFantasy;

/**
 *
 * @author quickstrikes96
 */
public class ServiceEquipeFantasy implements IServiceEquipeFantasy {

    @Override
    public void creer_equipefantasy(EquipeFantasy E) {
        
        
        
    }

    @Override
    public void ajouter_joueur_equipefantasy(EquipeFantasy E) {
    }
    
}
